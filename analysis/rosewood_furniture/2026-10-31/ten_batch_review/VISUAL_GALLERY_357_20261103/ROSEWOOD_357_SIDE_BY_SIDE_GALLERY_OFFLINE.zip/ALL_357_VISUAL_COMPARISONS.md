# 로즈우드 가구 357종 전체 이미지 대조목록

[36개 구간별 목록 및 첫 10종 미리보기](README.md) · [최종 검수 QA](../FINAL_QA_357_20261102/FINAL_QA_REPORT_KO.md)

**357/357개 비교 이미지** · 조건부 68 · 보류 289 · 게임 내 최종 1:1 인증 0개. 아래 구간 제목을 누르면 왼쪽 PZ 가구와 오른쪽 MC 후보가 함께 나오는 기존 비교 이미지를 볼 수 있어.

<details>
<summary><strong>001–010 (10종, 조건부 5 / 보류 5)</strong></summary>

[이 묶음만 보기](batches/BATCH_001_010.md)

### 001 — Chair / Grey · 조건부

![001 Chair PZ 왼쪽 MC 오른쪽](images/001_PZ_vs_MC.jpg)

금속 다리·등받이·어두운 시트라는 특징은 공통이지만 원본 등받이와 좌면 두께·지지대 모양이 다름. 이전 school chair도 무조건 확정하지 않음.

### 002 — Toilet / Fancy · 조건부

![002 Toilet PZ 왼쪽 MC 오른쪽](images/002_PZ_vs_MC.jpg)

흰 도기·뒤 물탱크·둥근 변기 볼 구조를 재확인. 이전 Paladin 모드는 일부 부품만 렌더됐으며 Decocraft 흰 변기는 실제 완성 모델을 로드. 뚜껑/탱크 비율이 다름.

### 003 — Cartbox / 기본 · 보류

![003 Cartbox PZ 왼쪽 MC 오른쪽](images/003_PZ_vs_MC.jpg)

기존 크레용 상자는 완전히 부적합. Wan 모드의 작은 종이상자는 마크 1.20.1 Forge 지원 및 25칸 수납이 공식 소개로 확인됨; PZ 원본도 ContainerCapacity 25. 상자 단독 바닥 배치와 모델 블록 ID는 추가 검증해야 함. 바닐라 갈색 셜커 상자는 27칸으로 기능 대안이지만 테이프 표현은 없음.

### 004 — Chair / Folding · 보류

![004 Chair PZ 왼쪽 MC 오른쪽](images/004_PZ_vs_MC.jpg)

기존 가죽 안락의자는 접이식 의자와 형태·용도가 다름. Blockables - Chairs의 folding stool은 등받이가 없어 동일하지 않음. 제시한 모드 및 바닐라 블록 조합만으로 1x1 안에 X자 금속 프레임/좌석/등받이를 정확 재현한 후보는 미검증. 별도 모드 탐색 또는 Blockbench 커스텀 필요.

### 005 — Round Bin / 기본 · 조건부

![005 Round Bin PZ 왼쪽 MC 오른쪽](images/005_PZ_vs_MC.jpg)

PZ는 검은색 원통형 솔리드 쓰레기통. 새 Decocraft 검정 원통형 쓰레기바구니는 실물 형태 유사하나 그물망 격자가 보여 재질 불일치; 바닐라 가마솥은 입구가 열려 있지만 네모 형태라 차선책.

### 006 — Chair / Green Dinner · 조건부

![006 Chair PZ 왼쪽 MC 오른쪽](images/006_PZ_vs_MC.jpg)

Green Dinner는 목재 프레임·세로 등받이 살·녹색 방석. 기존 초록 안락의자는 기각. Spruce 의자는 목재 프레임과 등받이가 비슷하지만 녹색 방석이 없고, diner_chair_green은 방석 색상은 비슷하나 금속 프레임이어서 최종 승인 보류.

### 007 — Shelves / Oakwood · 보류

![007 Shelves PZ 왼쪽 MC 오른쪽](images/007_PZ_vs_MC.jpg)

기존 Handcrafted acacia_shelf는 렌더가 막힌 진열장처럼 보여 원본의 빈 3단 목제 개방형 선반과 다름. 바닐라 빈 조각된 책장은 2열x3행 슬롯을 제공해 선반 구획·재질이 더 가까우나 PZ는 가로로 긴 3개 층이고 임의 물품 수납 기능도 다름. 새 모드의 오크 선반 모델 재검증 가능.

### 008 — Shelves / Large Metal · 보류

![008 Shelves PZ 왼쪽 MC 오른쪽](images/008_PZ_vs_MC.jpg)

원본은 두 스프라이트로 조립된 폭 2칸, 높이 약 2칸 금속 3단랙. Wan 공식 이미지에는 검정/남색 금속 프레임과 3단 선반이 있어 기존 빈칸보다는 좋은 후보. 다만 나무판 재질·모듈의 실제 연결 폭은 달라서 2칸 배치/적재 가능 여부 확인 전 최종 확정 금지. 바닐라 철 덫문+쇠창살 조합은 같은 블록공간을 공유하기 어려워 외형 대안 검증 전.

### 009 — Chair / Wooden · 조건부

![009 Chair PZ 왼쪽 MC 오른쪽](images/009_PZ_vs_MC.jpg)

기존 Paladin oak_chair_classic_black은 좌석/등받이 등 일부가 사라진 부품 불완전 렌더라 반려. Decocraft spruce 실제 Blockbench 완성 모델은 어두운 갈색 나무의자 4다리지만 PZ는 상단 가로판 위주인 간단한 등받이여서 유사도 미완벽.

### 010 — Counter / Steel · 보류

![010 Counter PZ 왼쪽 MC 오른쪽](images/010_PZ_vs_MC.jpg)

PZ는 낮은 철제 2도어 카운터와 4개의 다리, 하부 공간. 기존 적합 후보 미발견. 실버/라이트그레이 셜커 상자는 금속 느낌·1x1 크기·수납이라는 점에서 실용적 임시대체지만 정면 문 두 개와 다리를 표현하지 못함. Decocraft 하부장은 목재 상판이라 재질 차이가 큼. 정확 외형 유지하려면 별도 철제 카운터 모델 탐색/제작.

</details>

<details>
<summary><strong>011–020 (10종, 조건부 7 / 보류 3)</strong></summary>

[이 묶음만 보기](batches/BATCH_011_020.md)

### 011 — Locker / Metal · 보류

![011 Locker PZ 왼쪽 MC 오른쪽](images/011_PZ_vs_MC.jpg)

원본은 회색 금속 양문형 락커, Decocraft는 단문 루버 도어이고 실제 렌더에서 파란색으로 나와 색상/문 수가 다름. 최종 치환 보류. 다른 모드에서 양문형 회색 1칸 락커 검색.

### 012 — Chair / Dark Wooden · 조건부

![012 Chair PZ 왼쪽 MC 오른쪽](images/012_PZ_vs_MC.jpg)

원본은 짙은 갈색 네 다리 세로살 등받이 목재 의자. Decocraft Ebony 실모델은 다리와 등받이 구조가 근접하나 검정에 가까운 더 어두운 색임. 기존 Paladin 모델은 부품 누락이라 반려.

### 013 — Chair / Black Office · 조건부

![013 Chair PZ 왼쪽 MC 오른쪽](images/013_PZ_vs_MC.jpg)

바퀴·회전식 베이스는 원본과 같지만 새 Office Chair는 목재 슬랫 등받이와 팔걸이가 있고 PZ는 팔걸이가 없는 단순 패드형. 게임 의자는 과장된 고등받이라 차선.

### 014 — Recycle Bin / 기본 · 조건부

![014 Recycle Bin PZ 왼쪽 MC 오른쪽](images/014_PZ_vs_MC.jpg)

원본은 리브 무늬와 둥근 뚜껑이 있는 은회색 금속 쓰레기통. Decocraft Trash Can은 실제 렌더에서 둥근 통, 세로 주름, 윗뚜껑이 가까워 기존 불완전 Refurbished 렌더보다 낫지만 녹·손잡이 세부가 다름.

### 015 — Cabinet / White File · 조건부

![015 Cabinet PZ 왼쪽 MC 오른쪽](images/015_PZ_vs_MC.jpg)

원본은 아이보리색 금속 세 서랍 파일 캐비닛. Decocraft Filing Cabinet White는 정확히 세 서랍과 정면 손잡이 형태를 갖췄음. 아이보리 색상/낡은 정도와 손잡이 간격은 다름. 기존 주방 수납장 반려.

### 016 — Hood / Extractor · 조건부

![016 Hood PZ 왼쪽 MC 오른쪽](images/016_PZ_vs_MC.jpg)

원본의 은색 비스듬한 배기후드에 가까운 벽걸이 모델을 확보. 다만 새 Wall Hood는 상부 덕트가 더 높고 원본의 검은 상단 띠와 구조가 다름. 이전 Refurbished 렌더는 일부 큐브만 보였음.

### 017 — Chair / Plastic · 보류

![017 Chair PZ 왼쪽 MC 오른쪽](images/017_PZ_vs_MC.jpg)

PZ는 하나로 성형된 흰 플라스틱 야외 의자로 곡선 등받이와 일체형 팔걸이. 새 라탄 의자는 직조+두꺼운 방석이고 Beach Chair는 캔버스형. 둘 다 재질/구조가 달라 최종 매칭 보류. Skniro 등에서 플라스틱 성형 의자 추후 탐색.

### 018 — Counter / Modern · 조건부

![018 Counter PZ 왼쪽 MC 오른쪽](images/018_PZ_vs_MC.jpg)

원본은 어두운 목재 2도어 하부장과 밝은 베이지색 상판. 새 Spruce 하부장은 갈색 본체+밝은 상판으로 접근하지만 위쪽 서랍 한 개와 아래 문 한 개로 원본 2도어 구조와 다르고 높이도 달라 설치 비교 필요.

### 019 — Sink / White Standing · 보류

![019 Sink PZ 왼쪽 MC 오른쪽](images/019_PZ_vs_MC.jpg)

PZ는 독립형 하얀 도기 세면대로 긴 받침 기둥을 가진다. 새 Wall Sink White는 수전과 물받이만 유사하며 벽에 설치되어 페데스털이 없음. Round Sink Silver도 상판 거치형. Skniro/욕실 가구 모드에서 받침 기둥 포함 모델 탐색 보류.

### 020 — Counter / Birchwood · 조건부

![020 Counter PZ 왼쪽 MC 오른쪽](images/020_PZ_vs_MC.jpg)

원본은 꿀빛 갈색 단정한 장식 없는 카운터. 새 Oak 하부장은 따뜻한 나무색은 가까우나 흰 상판, 장식 문짝/서랍이 추가됨. 기존 Macaw Birch Counter는 회색 몸통이라 더 먼 후보. 바닐라 배럴/각목 블록도 추후 비교 가능.

</details>

<details>
<summary><strong>021–030 (10종, 조건부 6 / 보류 4)</strong></summary>

[이 묶음만 보기](batches/BATCH_021_030.md)

### 021 — Bath / Large Deluxe · 조건부

![021 Bath PZ 왼쪽 MC 오른쪽](images/021_PZ_vs_MC.jpg)

원본 PZ는 두 타일로 구성되는 긴 흰색 욕조. Decocraft Bathtub White는 하얀 사각 욕조·내부 공간·끝 수전 모양이 매우 가깝다. 단 PZ 조립 프리뷰에 떨어져 보이는 수도꼭지 한 조각은 조립 미확정이므로 시각 검수 전 수정 필요. MC 실제 배치 면적과 연결 기능은 미확인.

### 022 — Cabinet / Medicine · 보류

![022 Cabinet PZ 왼쪽 MC 오른쪽](images/022_PZ_vs_MC.jpg)

PZ는 옆면 깊이와 작은 문/손잡이가 있는 벽걸이 약품장. 실제 Decocraft Rectangular Mirror Silver는 거울뿐이라 수납 몸체가 없다. Middle Cabinet White는 몸체만 있고 거울이 없다. 둘 모두 원본의 문+거울+수납 기능을 동시에 갖추지 못하므로 기존 Macaw 주방장 매칭도 반려하고 보류.

### 023 — Drawers / Fancy Oak · 조건부

![023 Drawers PZ 왼쪽 MC 오른쪽](images/023_PZ_vs_MC.jpg)

원본은 진갈색 캐비닛형 3단 서랍장과 황동 원형 손잡이. Bedside Table Ebony는 2단 서랍장으로 어두운 갈색 톤·4다리는 비슷하지만 서랍 개수, 손잡이 모양, 가구 높이가 다르다. Modular Desk Drawers Oak도 2단에 색상이 밝아 대안으로만 기록.

### 024 — Table / Large Oak · 보류

![024 Table PZ 왼쪽 MC 오른쪽](images/024_PZ_vs_MC.jpg)

원본 완성형 테이블은 2개 타일로 연결된 길쭉한 직사각 탁자이며 가느다란 검은 다리 네 개가 있다. Decocraft Wooden Table Oak는 목재 단색 1×1 정사각 탁자에 굵고 장식적인 다리라 비율·재질·부피가 다르다. Kitchen Table Oak도 흰 상판이므로 부적합. 기존 Macaw Oak Table의 큐브형 렌더 역시 원본과 불일치.

### 025 — Counter / White · 조건부

![025 Counter PZ 왼쪽 MC 오른쪽](images/025_PZ_vs_MC.jpg)

원본은 크림색 두 문짜리 카운터. Decocraft Bottom Cabinet 1 White는 흰색 몸체가 가깝지만 위 한 서랍+아래 한 문, 상판 목재색이라 2도어 크림색 원본과 차이. Bottom Cabinet 2 White는 서랍 4개라 더 나쁨. 기존 1 White를 조건부 후보로만 유지.

### 026 — Shelves / Low · 보류

![026 Shelves PZ 왼쪽 MC 오른쪽](images/026_PZ_vs_MC.jpg)

원본은 높이가 낮은 개방형 목재 3단 선반. Decocraft China Cabinet Open Oak는 거대한 유리문/접시/서랍이 붙은 장식장이라 종류가 다르다. 기존 Handcrafted Acacia Shelf는 실제 렌더가 원본과 달리 전면이 막힌 진열장 형태로 나와 승인 불가.

### 027 — Counter / Oak · 조건부

![027 Counter PZ 왼쪽 MC 오른쪽](images/027_PZ_vs_MC.jpg)

원본은 중간 갈색 오크 2도어 캐비닛과 갈색 목제 상판. Bottom Cabinet 1 Oak는 목재 색감은 가깝지만 상판 흰색, 상단 서랍+하부 단문 구성이며 Bottom Cabinet 2 Oak는 4단 서랍이라 더 부적합. 기존 Macaw Dark Oak Counter는 어두운 직육면체라 더 멀어 조건부 1 Oak로 교체 제안.

### 028 — Green Garbage Bin / 기본 · 보류

![028 Green Garbage Bin PZ 왼쪽 MC 오른쪽](images/028_PZ_vs_MC.jpg)

PZ 원본은 짙은 초록색 원통 몸체와 검정 테두리 비닐이 있는 개방 쓰레기통. Decocraft Trash Can Open은 회색 골판형 큰 쓰레기통으로 뚜껑이 옆에 떨어져 있으며 검정 격자 바구니는 철망형이라 외형이 달라. 기존 Paladin Mesh Trashcan도 격자·초록 배경이 뒤엉킨 부분 렌더로 승인 불가.

### 029 — Sink / Industrial · 조건부

![029 Sink PZ 왼쪽 MC 오른쪽](images/029_PZ_vs_MC.jpg)

PZ 원본은 얕은 네모 물받이와 높게 굽은 금속 수도꼭지. Decocraft Kitchen Sink Silver 모델은 사각 물받이·높은 호스형 수전·금속 색상이 꽤 닮았다. Square Sink Silver도 유사하지만 베이슨 형태가 다르므로 전자를 우선. 원본은 독립 받침 없는 인셋형이라 싱크 하부 조합 공간이 맞는지 필요.

### 030 — Chair / Blue Plastic · 조건부

![030 Chair PZ 왼쪽 MC 오른쪽](images/030_PZ_vs_MC.jpg)

PZ는 등받이 중앙에 손잡이 구멍이 뚫린 파란 플라스틱 의자와 검정 가는 금속 다리. School Chair Blue는 파란 시트·등받이·금속 다리 구성이 맞지만 등받이가 네모이고 손잡이 대신 회색 박음점, 좌석이 직사각이라 상당한 차이. Diner Chair Blue는 흰 줄무늬가 있어 더 멀다. 조건부만.

</details>

<details>
<summary><strong>031–040 (10종, 조건부 5 / 보류 5)</strong></summary>

[이 묶음만 보기](batches/BATCH_031_040.md)

### 031 — Counter / Wooden · 조건부

![031 Counter PZ 왼쪽 MC 오른쪽](images/031_PZ_vs_MC.jpg)

PZ는 어두운 갈색 나무의 양문 하부장과 목재 상판. 새 Decocraft Ebony는 어두운 목제 전체 형태는 비슷하지만 실제 원본은 서랍+단문(또는 한 장 문), 검정 상판이라 양문 구조가 다름. Spruce는 목재 갈색이 약간 밝고 흰 상판이어서 대안으로만. 기존 Macaw Dark Oak Counter는 통짜 블록 렌더라 거부.

### 032 — X-press / Coffee · 보류

![032 X-press PZ 왼쪽 MC 오른쪽](images/032_PZ_vs_MC.jpg)

기존 대나무 원탁 매칭은 가구 종류 자체가 틀려 폐기. 추가 확인한 Decocraft Coffee Grinder는 나무 손잡이 수동 분쇄기라 전기 드립 커피메이커가 아님. Minecraft 1.20.1 Forge CoffeeCraft 모드에 커피메이커 블록이 있다는 공개 자료는 확인했으나, 구체적인 블록 ID와 원본 모델 외형은 직접 렌더하지 못해서 보류.

### 033 — Sink / Chrome · 조건부

![033 Sink PZ 왼쪽 MC 오른쪽](images/033_PZ_vs_MC.jpg)

PZ 원본은 은색 좌우 2조 볼과 높은 곡선 수전. 새 Kitchen Sink Silver는 은색 재질·수전과 설치 용도는 가깝지만 단일 볼 형태라 쌍볼 구조를 잃음. 기존 Paladin Basic Sink는 일부 평판만 렌더돼 무효. 쌍볼 모드 모델을 계속 검색하며 이번 후보는 조건부만.

### 034 — Chair / Fancy Wooden · 조건부

![034 Chair PZ 왼쪽 MC 오른쪽](images/034_PZ_vs_MC.jpg)

기존 Paladin Oak Chair Classic Black은 모형 좌석과 등받이가 빠진 부분 렌더로 무효. 새 Decocraft Chair 1 Ebony는 진한 나무 프레임, 네 다리, 등받이 세로살 구성이 비슷하지만 분홍·보랏빛 방석이 없고 색상 자체도 더 검정. Cherry는 프레임이 너무 연분홍. 미세한 좌석 색상은 커스텀 리텍스처 없이는 불일치.

### 035 — Bench / Oakwood · 보류

![035 Bench PZ 왼쪽 MC 오른쪽](images/035_PZ_vs_MC.jpg)

PZ는 2타일을 합친 긴 갈색 야외 등받이 없는 벤치. 이전 Decocraft Gym Bench는 운동기구로 부적합. 새 Decocraft Decobench는 실제 목공 작업대라 전혀 다른 물건. Piano Bench Spruce는 긴 좌석 형태를 일부 갖추나 실물 길이가 짧고 피아노용 단일 스툴에 가까워 거절. Handcrafted Oak Bench는 소스 블록 ID가 존재하지만 현재 비교 렌더 미확인.

### 036 — Blower / Air · 보류

![036 Blower PZ 왼쪽 MC 오른쪽](images/036_PZ_vs_MC.jpg)

PZ 원본은 작은 검정 벽걸이 공기 건조기. 기존 `decocraft:dryer`는 커다란 세탁 건조기이며 원본 `.bbmodel`이 정상 표시돼도 종류가 완전히 다르므로 반려. 확인된 Decocraft JAR에는 정확한 hand dryer 모델이 없음.

### 037 — Chair / White Wooden · 조건부

![037 Chair PZ 왼쪽 MC 오른쪽](images/037_PZ_vs_MC.jpg)

PZ의 흰색 나무 의자는 곧은 4다리와 세로살 등받이·평평한 좌석. Decocraft Chair 1 White는 실제 원본 20큐브 모델에서 흰 목재·세로살 4다리 형태가 상당히 닮아 기존 Paladin 반쪽 렌더보다 적합. Chair 2 White는 X등받이여서 더 다르다. 곡면·등받이 비례는 차이.

### 038 — Shelves / White Fancy · 보류

![038 Shelves PZ 왼쪽 MC 오른쪽](images/038_PZ_vs_MC.jpg)

원본은 빈 3단 선반이 보이는 날렵한 흰 목재 책장. 기존 Decocraft Dish Rack White는 접시걸이로 틀렸고, 새 Decocraft China Cabinet Open White는 유리문·장식품·하부 서랍이 있는 거대한 찬장이어서 다른 가구. Modular Desk Storage White도 가로형 책상 장식품이다. Macaw's Stripped Birch Bookshelf는 후보 ID만 확인되어 완성 렌더 비교 전으로 보류.

### 039 — Drawers / Bedroom · 보류

![039 Drawers PZ 왼쪽 MC 오른쪽](images/039_PZ_vs_MC.jpg)

원본은 연한 갈색 1단 서랍과 아래가 빈 오픈칸 1개. Decocraft Bedside Table Open 1 Oak/Birch는 위 서랍이 열린 상태이며 아래에 또 손잡이/서랍이 있어 원본 오픈 선반과 구조가 다름. Open 2는 아랫서랍만 열린 2단 서랍장이어서 더 나쁨. 기존 Macaw acacia bookshelf drawer는 판 한 장만 표시된 불완전 렌더라 무효.

### 040 — Table / Small · 조건부

![040 Table PZ 왼쪽 MC 오른쪽](images/040_PZ_vs_MC.jpg)

PZ는 진갈색 상판과 굵은 직선 네 다리를 가진 작은 정사각 나무 탁자. Decocraft Wooden Table Oak는 네 다리/상판/탁자 역할은 같지만 상판이 밝은 베이지색이고 다리에 장식 링이 많으며 실제 높이·두께도 다름. Cherry는 분홍색이라 더 다름. 기존 Wrought Iron Small Black은 원형 금속 다리라 형태가 틀림.

</details>

<details>
<summary><strong>041–050 (10종, 조건부 6 / 보류 4)</strong></summary>

[이 묶음만 보기](batches/BATCH_041_050.md)

### 041 — Sink / White Hanging · 조건부

![041 Sink PZ 왼쪽 MC 오른쪽](images/041_PZ_vs_MC.jpg)

좀보이드 원본은 흰색 벽걸이 세면대, 금속 수전 둘, 아래 배수구가 보임. 새 Decocraft Wall Sink White 실제 모델은 흰색 몸체/수전/아래 배수 파이프가 갖춰져 기존 Refurbished 분홍색 단일 평판보다 매우 적합. 다만 정사각형 볼과 높은 뒷판은 원본 둥근 도기와 비율 차이.

### 042 — Television / ValuTech · 조건부

![042 Television PZ 왼쪽 MC 오른쪽](images/042_PZ_vs_MC.jpg)

원본 ValuTech TV는 두껍고 뒤로 튀어나온 검정/회색 브라운관 TV(원본 좌우 비교는 뒷면 시점). 새 Decocraft CRT TV는 검은색 두꺼운 박스형 모니터와 전면 화면을 갖추어 기존 Refurbished의 큐브형 그래픽보다 명확히 낫다. Tv Old는 나무 외장·안테나가 달려 시대와 외형이 다름.

### 043 — Couch / Blue Rattan · 조건부

![043 Couch PZ 왼쪽 MC 오른쪽](images/043_PZ_vs_MC.jpg)

기존 Macaw Blue Couch는 파란색 단일 블록/좌석이며 갈색 라탄 질감이 없어 전혀 맞지 않는다. 새 Decocraft Rattan Couch Brown 왼쪽·오른쪽 모델은 실제 원본 소스에서 등받이·라탄 옆면·다리·좌석을 각각 확인한 완전형 모듈이다. 하지만 쿠션은 크림색으로 원본의 짙은 회색과 색상이 어긋나며, 두 블록으로 붙인 조립 완성형은 아직 게임에서 확인하지 않았다. 카드에는 좌우 단독 모듈을 각각 보여준다.

### 044 — Sink / White · 조건부

![044 Sink PZ 왼쪽 MC 오른쪽](images/044_PZ_vs_MC.jpg)

원본은 얕고 둥근 흰색 매입형 도기 세면대에 짧은 금속 수도꼭지들이 있다. 새 Decocraft Round Sink Silver는 흰 둥근 물받이·수전이 비슷하지만 팔각형 볼, 긴 한 개 수전, 큰 받침/배수구가 달라 모양이 정확히 같지는 않다. 기존 Refurbished는 평판만 나온 불완전 모델이므로 교체.

### 045 — Low Table / Light · 조건부

![045 Low Table PZ 왼쪽 MC 오른쪽](images/045_PZ_vs_MC.jpg)

원본은 밝은 황갈색 매끈한 낮은 탁자와 굵은 네 다리. 새 Decocraft Bamboo Square Yellow는 비슷한 밝은 목재 상판·낮은 크기를 갖지만 옆면이 X자 라탄 격자라 원본의 열린 네 다리 구조와 다름. Cottage Coffee Table은 다리는 간결하지만 색상이 매우 어두워 보조 대안. 기존 Macaw는 회색 매끈한 석판처럼 나타나 부적합.

### 046 — Shelves / Large Shop · 보류

![046 Shelves PZ 왼쪽 MC 오른쪽](images/046_PZ_vs_MC.jpg)

원본 2개 타일을 합친 상점 진열대인데 현재 그림은 넓고 매끈한 뒷판이 강조되어 실제 상품 진열 선반 쪽 전면이 불분명하다. 기존 Handcrafted Acacia Shelf는 폭 1칸 짜리 닫힌 목제 상자 같아 비율과 종류가 다름. 추가 Decocraft China Cabinet White도 문·접시·서랍이 있는 가정용 찬장으로 상점 전용 2칸 선반과 불일치. 원본 반대 시점 확인 전 확정 불가.

### 047 — Sink / Dark Industrial · 조건부

![047 Sink PZ 왼쪽 MC 오른쪽](images/047_PZ_vs_MC.jpg)

원본 Dark Industrial Sink는 진회색 은색 철제 사각 볼, 높은 꺾인 수도꼭지. 새 Kitchen Sink Black은 사각 볼·높은 호형 수전·어두운 손잡이로 기존 Paladin 평판 모델보다 좋다. 다만 모델의 바닥 몸체가 흰색이며 수전 전체가 검게 바뀌어서 원본 금속 광택과 상충. Silver 변형과 색상 재비교 필요.

### 048 — Computer / Desktop · 보류

![048 Computer PZ 왼쪽 MC 오른쪽](images/048_PZ_vs_MC.jpg)

PZ는 오래된 베이지색 CRT 모니터, 수평 케이스, 키보드가 모두 있는 완성 데스크톱. 기존 Refurbished Computer는 금색 큰 정육면체 한 부품만 렌더링되어 매칭 불가능. 새 Decocraft Monitor 1 White는 모니터와 키보드 형태가 있지만 화면이 얇은 현대식 LCD, 화려한 방송용 조작패널, 별도 CRT 몸체가 없어 원본과 크게 다르다. 다른 전자기기 모드를 조사해야 한다.

### 049 — Locker / Yellow Wall · 보류

![049 Locker PZ 왼쪽 MC 오른쪽](images/049_PZ_vs_MC.jpg)

원본은 두 개의 문과 가운데 손잡이 두 개가 있는 노란색 금속 사물함. Decocraft Locker Yellow와 Gray의 실모델을 모두 렌더했지만 노란색이 적용되지 않고 파란색 단일 루버 도어로 나왔으며 문 개수·힌지/손잡이가 원본과 달라. 색상 레이어 로더 문제 가능성을 배제할 수 없지만 단순히 노란색이라고 ID가 붙었다고 승인하면 안 됨.

### 050 — Shelves / Metal Wall · 보류

![050 Shelves PZ 왼쪽 MC 오른쪽](images/050_PZ_vs_MC.jpg)

PZ 원본은 벽에 매달린 2단 금속 격자형 얕은 바구니 선반이다. 기존 Handcrafted Acacia Shelf는 문 있는 나무 수납장처럼 나와 부적합. 새 Decocraft Drying Rack Black은 건조 접시와 바닥 받침대가 있는 독립형이라 다른 가구이고 Spice Rack White는 흰 통조림 양념장이라 철망과 달라. 바닐라 철 덫문/쇠창살로 선반을 근사할 수는 있으나 한 블록 내부 중첩·벽 부착 방식이 아직 검증되지 않았다.

</details>

<details>
<summary><strong>051–060 (10종, 조건부 4 / 보류 6)</strong></summary>

[이 묶음만 보기](batches/BATCH_051_060.md)

### 051 — Dark Round Table / 기본 · 조건부

![051 Dark Round Table PZ 왼쪽 MC 오른쪽](images/051_PZ_vs_MC.jpg)

PZ는 진갈색 목제 원형 상판+중앙 기둥과 갈라진 다리다. 실제 Decocraft Diner Table Round Black(21 cubes)은 원형/중앙 기둥/삼발이 구조가 비슷하지만 검정 상판·회색 금속 지지대여서 목재 재질은 불일치. Bamboo Round Yellow는 노란 4다리 격자라 하부형태가 더 멀다. 기존 Macaw 모델은 정사각 두꺼운 석판처럼 렌더되어 반려.

### 052 — Table / Large Simple · 보류

![052 Table PZ 왼쪽 MC 오른쪽](images/052_PZ_vs_MC.jpg)

PZ는 길이 2칸 밝은 나무 높은 테이블, 철제 검정 접이식 가대형 다리이다. 새 Cottage Coffee Table Long은 단색 어두운 갈색이고 높이가 낮고 얇은 나무다리라 형태/재질/높이가 전부 달라 정답으로 승인하지 않는다. 기존 Decocraft Table Setting Double은 아예 접시·컵 세트였으므로 완전 반려.

### 053 — Low Table / Fancy · 조건부

![053 Low Table PZ 왼쪽 MC 오른쪽](images/053_PZ_vs_MC.jpg)

PZ는 어두운 갈색 모서리 가공 상판과 바깥으로 휘는 네 다리가 있는 작은 낮은 탁자. 새 Cottage Coffee Table 실제 원본 33 cubes 모델은 목재 색감·낮은 상판·네 다리 형태가 유사해 기존 Macaw 회색 두꺼운 석판보다 낫다. 다만 원본은 더 작고 다리는 더 장식적이므로 정확한 일치가 아니다.

### 054 — Box / Battered Cartboard · 보류

![054 Box PZ 왼쪽 MC 오른쪽](images/054_PZ_vs_MC.jpg)

PZ는 찌그러진 옅은 갈색 종이박스로, 테이프와 찢어지거나 구겨진 윗부분이 중요하다. 기존 Refurbished Mail Box는 불완전한 큰 목제 기둥 형태로 아예 종류가 틀리다. 실제 Decocraft 25개 후보 목록에는 닮은 종이상자가 없어서 우측에 없는 모델의 가상 렌더를 만들지 않는다. Forge 1.20.1 호환 Cardboard box 모드와 Shipping은 배포처 확인까지만 했다.

### 055 — Bed / Large Oak · 조건부

![055 Bed PZ 왼쪽 MC 오른쪽](images/055_PZ_vs_MC.jpg)

PZ 원본은 큰 연한 참나무 침대 틀에 연속된 흰 침구, 등받이는 넓은 수평 나무판, 발치에는 낮은 나무 프레임. Decocraft Oak White는 36 cubes로 정상 렌더되며 원목 프레임·흰 침구는 가까우나 흰 회색 체크 패턴, 분리된 베개, 세로살 머리판·발치 난간이 원본과 명확히 다르다. 기존 매칭은 조건부였으나 외형을 재평가해 조건부 유지.

### 056 — Oven / Modern · 조건부

![056 Oven PZ 왼쪽 MC 오른쪽](images/056_PZ_vs_MC.jpg)

PZ는 4개의 검은 둥근 화구·은회색 오븐 본체·전면 제어 노브·검정 오븐창·높은 검정 뒷판을 가진다. Decocraft Stove 실제 98큐브 모델은 4구 상판·노브·은회색 전면/검정 창을 모두 갖춰 기존 Paladin Gray Stove의 단일 막대 누락 모델보다 훨씬 정확하다. 다만 화구는 사각 격자, 검정 뒷판 생략, 손잡이/도어 높이 차이. 게임에서 요리 기능은 별도로 확인해야 한다.

### 057 — Bin / Wheelie · 보류

![057 Bin PZ 왼쪽 MC 오른쪽](images/057_PZ_vs_MC.jpg)

PZ는 초록색 긴 본체, 상단 양쪽 덮개, 뒤쪽 손잡이와 밑바퀴 2개가 있는 이동식 쓰레기통. 기존 Refurbished recycle bin은 회색 일반 통으로 뚜껑/바퀴가 없고 부품도 불완전하다. 새 Decocraft Pedal Trash Can은 직육면체에 덮개는 있으나 회색이며 작은 바닥 페달뿐이어서 колес wheelie bin과 전혀 다름. Skart's Decorations 0.3 1.20.1 Forge에 Wheelie Bins 추가 이력이 있으나 모델 ID/초록 변형 실제 렌더 필요.

### 058 — Chair / Grey Plastic · 보류

![058 Chair PZ 왼쪽 MC 오른쪽](images/058_PZ_vs_MC.jpg)

PZ는 한 몸체로 굽어진 회보라 플라스틱 좌석과 등받이, 가운데 손잡이 구멍, 검정 얇은 금속 다리. 새 Diner Chair Gray는 색상과 금속다리가 비슷하나 등받이가 납작한 사각판에 굵은 흰 줄무늬가 있고 구멍이 없다. School Chair Gray도 판형 등받이와 금속 직선다리라 동일한 성형 의자가 아니다. 기존 PFM Gray Arm Chair는 안락의자 블록 형태로 구조 불일치.

### 059 — Bench / Park · 보류

![059 Bench PZ 왼쪽 MC 오른쪽](images/059_PZ_vs_MC.jpg)

PZ는 목제 2줄 등받이+긴 이중 나무판 좌석+얇은 갈색 철제 받침다리로 구성되는 길쭉한 공원 벤치다. 기존 Decocraft Gym Bench는 헬스장 운동 기구였고 새 Piano Bench Spruce는 등받이도 없고 폭도 1칸인 피아노 의자라 둘 다 불합격. Just Outdoor Stuffs는 1.20.1 Forge 지원과 2인 벤치 기능까지 공식 소개에서 확인됐지만 실제 모델과 PZ처럼 2칸인지 아직 확인하지 않았다.

### 060 — Drawers / Fancy · 보류

![060 Drawers PZ 왼쪽 MC 오른쪽](images/060_PZ_vs_MC.jpg)

PZ는 크림 흰색 목제 3단 서랍장이며 서랍마다 검정 동그란 손잡이 2개(총 6개). 새로운 Decocraft Filing Cabinet White는 실제 렌더에서 3단이긴 하나 흰 철제 문서 보관함으로 각 서랍마다 긴 금속 손잡이와 라벨 칸이 있다. Modular Desk Drawers White는 흰색 목제에 가깝지만 2단만 있어 둘 다 완성형으로는 맞지 않는다. 기존 Macaw BookShelf Drawer 렌더는 초록 판 한 장이라 무효.

</details>

<details>
<summary><strong>061–070 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_061_070.md)

### 061 — Wardrobe / Oak · 보류

![061 Wardrobe PZ 왼쪽 MC 오른쪽](images/061_PZ_vs_MC.jpg)

PZ 전체는 짙은 오크색 양문형 옷장+하단 긴 한 칸 서랍, 가로폭 2칸으로 완성된다. Decocraft Closet 6 Oak는 밝은 오크 단문형으로 바닥 서랍과 두 손잡이가 없고, Closet 3 Oak는 3단 서랍장, Closet 5 Oak는 열린 의류칸이므로 모두 다른 물건이다. 기존 Macaw oak_double_wardrobe의 소스 렌더도 실제 문/하단 서랍을 보여주지 못한다. 다른 모드 검증 전 최종 선택 불가.

### 062 — Chair / Blue Rattan · 조건부

![062 Chair PZ 왼쪽 MC 오른쪽](images/062_PZ_vs_MC.jpg)

PZ는 갈색 라탄을 둘러 엮은 양 팔걸이와 짙은 회색 직물 등받이/좌석 쿠션의 1인 소파이다. 새 Decocraft Rattan Armchair Brown 원본 10큐브 모델은 갈색 라탄 직조 프레임·양쪽 팔걸이·좌석 쿠션 형태가 가까워 기존 PFM Blue Arm Chair(파란 직육면체 렌더)보다 훨씬 낫다. 다만 실제 MC는 쿠션이 흰색으로 차이가 크고 등받이가 직각 평판이라 원본의 둥근 등받이와 다름.

### 063 — Drawers / Light Wood · 보류

![063 Drawers PZ 왼쪽 MC 오른쪽](images/063_PZ_vs_MC.jpg)

PZ 원본 사진에 연갈색 뒷판만 보여 전면 서랍의 개수·손잡이 배치가 확인되지 않았다. 과거 Macaw Bookshelf Drawer의 렌더는 초록색 얇은 판이라 가구의 전면과 무관. Decocraft Modular Desk Drawers Oak는 2단 서랍과 은색 손잡이로 실모델은 완성됐지만 원본의 전면이 확인되지 않아 닮았다고 승인할 근거가 없다.

### 064 — Counter / Steel Corner · 보류

![064 Counter PZ 왼쪽 MC 오른쪽](images/064_PZ_vs_MC.jpg)

PZ 원본은 은색 균일 금속 상판에 직각으로 꺾인 L자 코너 홈이 있고 측면은 매끈한 회색 금속 함체. 새 Decocraft Diner Counter Corner Light Gray는 45도처럼 둥글게 모서리가 잘린 카페 카운터이며 수평 줄무늬와 검정 바닥이 있어 직각 스테인리스 주방 코너와 불일치. 기존 Black variant는 더 색이 달라 승인 불가.

### 065 — Shelves / Big Wall · 보류

![065 Shelves PZ 왼쪽 MC 오른쪽](images/065_PZ_vs_MC.jpg)

PZ는 벽 쪽 베이지 나무 뒷판에 돌출된 갈색 넓은 수평 선반 3칸이 비어 있는 구조다. 기존 Handcrafted Acacia Shelf는 불투명 상자처럼 렌더돼 전면이 제대로 보이지 않는다. 새 Decocraft China Cabinet Open Oak는 유리 찬장, 접시/서랍/문까지 있어 수납 종류가 다르고, Spice Rack Oak는 매우 작은 양념병 2단이라 선반 수·크기·비품 내용이 모두 어긋난다.

### 066 — Bench / Fancy Outdoors · 보류

![066 Bench PZ 왼쪽 MC 오른쪽](images/066_PZ_vs_MC.jpg)

원본은 2칸 긴 목재 가로살 좌석·등받이와 검정 금속 곡선 양 팔걸이/다리로 꾸민 공원 벤치다. 예전 Decocraft Gym Bench는 역기 운동 장비, 이번 Decocraft Decobench 실제 모델은 이름과 다르게 작업 도구/파란 제작판이 달린 실내 작업대(!)이므로 또 잘못된 종류. Rattan Couch Left도 1인 실내 라탄 좌석이며 야외 벤치가 아님.

### 067 — Low Table / Brown · 보류

![067 Low Table PZ 왼쪽 MC 오른쪽](images/067_PZ_vs_MC.jpg)

PZ는 낮고 짙은 갈색 상판 아래 전면이 열려 있는 2단 선반형 커피테이블/TV장. 기존 Decocraft Rattan Coffee Table은 밝은 회색 상판과 라탄 외벽으로 열린 앞면이 보이지 않아 불합격. 새 Bedside Table Open 2 Ebony는 뚜껑 열려 나온 서랍 2개와 커다란 높이의 협탁으로 실제로는 '개방형 선반'이 아니며 PZ의 낮은 높이도 맞지 않는다.

### 068 — Chair / Red Wooden · 보류

![068 Chair PZ 왼쪽 MC 오른쪽](images/068_PZ_vs_MC.jpg)

PZ는 짙은 와인색 붉은 목제 의자, 등받이에는 한 개의 짧은 수평대만 있고 아래가 뚫린 단순한 형태. 기존 PFM Oak Chair Classic Red는 좌석/등받이가 아닌 일부 목재 다리/네온 색 선분만 표시된 부품 불완전 렌더. 새 Decocraft Chair 1 Cherry는 연분홍 벚나무색에 많은 세로살 등받이가 있고, Chair 2 Cherry는 X자 교차살, School Chair Red는 금속다리 플라스틱 소재라 모두 원본 색·등받이 구조 불일치.

### 069 — Table / Large Light Oak · 보류

![069 Table PZ 왼쪽 MC 오른쪽](images/069_PZ_vs_MC.jpg)

PZ 완성형은 2칸 긴 크림색 나무 상판과 각 모서리의 가는 직선 목제 다리 4개다. 기존 Macaw Dark Oak Glass Table은 유리판 한 장만 로드됐고 목재 색부터 다름. 새 Decocraft Wooden Table Birch는 나무재질과 상판 색은 가깝지만 1칸 정사각형에 굵고 장식적인 다리 4개이고 두 개를 나란히 두면 중앙 이음매·다리가 중복될 수 있어 PZ 완성형 2칸 식탁 대체로 인증할 수 없다.

### 070 — Toilet / Hanging · 보류

![070 Toilet PZ 왼쪽 MC 오른쪽](images/070_PZ_vs_MC.jpg)

중요: PZ 이름 'Toilet/Hanging'이지만 원본 이미지는 바닥에 설치하는 변기가 아니라 벽에 매다는 흰색 남성 소변기다. 기존 PFM Basic Toilet은 앉는 일반 양변기라 오매칭이고 이번 Decocraft Toilet White 실모델(93 cubes)도 뚜껑·좌석·물통 있는 일반 변기다. 다른 1.20.1 Forge Toilet Real과 Toilet Remake는 소변기 설치를 제공하지만 공식 모델/벽걸이 형태의 JAR 렌더는 확인하지 못했기에 아직 승인하지 않는다.

</details>

<details>
<summary><strong>071–080 (10종, 조건부 3 / 보류 7)</strong></summary>

[이 묶음만 보기](batches/BATCH_071_080.md)

### 071 — Table / Light Wood Restaurant · 보류

![071 Table PZ 왼쪽 MC 오른쪽](images/071_PZ_vs_MC.jpg)

PZ 원본은 밝은 원목 정사각 상판에 갈색 가는 한 기둥과 십자 다리의 카페용 탁자다. 기존 Macaw glass table은 상판 평판 한 조각만 나타나 전혀 검증되지 않는다. 실제 Decocraft Diner Table Yellow/Light Gray는 정사각 상판과 중앙 기둥은 비슷하지만 상판이 노란 플라스틱/회색 금속이고, 넓은 사각 금속 바닥판이라 원본의 나무색/십자 발과 구조가 다르다. Round variant는 상판이 원형으로 더 어긋난다.

### 072 — Chair / White Simple · 조건부

![072 Chair PZ 왼쪽 MC 오른쪽](images/072_PZ_vs_MC.jpg)

PZ는 연한 크림색의 얇은 네 다리 목제 의자로 등받이에 하나의 넓은 사각 틈이 있다. 기존 PFM Oak Chair Classic White는 다리 몇 개와 붉은 막대만 나온 불완전 모델이다. 새 Decocraft Chair 1 White를 직접 렌더해 흰 목제 4다리·좌석·등받이가 모두 구현된 것을 확인했다. 다만 등받이에 세로살 여러 개가 있어 PZ의 단일 큰 사각 틈과 다르며 화이트 색감도 더 밝다. Chair 2 White는 X자라 더 멀다.

### 073 — Cabinet / First Aid · 보류

![073 Cabinet PZ 왼쪽 MC 오른쪽](images/073_PZ_vs_MC.jpg)

PZ는 빨간 사각 휴대용 구급상자에 위 손잡이, 녹색 바탕 흰 십자가 표지, 잠금쇠가 있다. 이전 Macaw Double Kitchen Cabinet은 큰 주방 수납장이어서 가구 종류 자체가 틀리다. 새 Decocraft Lunch Box Red BBMODEL도 열어 보니 음식/음료를 펼쳐 놓은 도시락 장면이라 구급상자와 전혀 다른 물건이다. Hospitals Forge 1.20.1에는 Small/Large First Aid Kit가 있지만 모델·블록 설치 가능 여부를 아직 렌더링하지 않아 매칭 확정 불가.

### 074 — Bin / Grey Garbage · 보류

![074 Bin PZ 왼쪽 MC 오른쪽](images/074_PZ_vs_MC.jpg)

PZ는 키 큰 회색 각형 쓰레기통이고 위는 짙은 회흑색 경사진 돔형/투입구 덮개다. 기존 Refurbished Recycle Bin은 하얀 상판+세로 홈의 낮은 통형 블록 일부만 보였다. 실제 Decocraft Pedal Trash Can 모델은 회색 네모 통이지만 윗면이 평평하고 바닥 페달이 노출되며 검정 높다란 쓰레기통 덮개가 없다. Decocraft Trash Can은 손잡이 원통형이라 더 다르다.

### 075 — Dumpster / Orange · 보류

![075 Dumpster PZ 왼쪽 MC 오른쪽](images/075_PZ_vs_MC.jpg)

원본은 2타일 길이의 녹슨 주황색 대형 쓰레기통과 검정 굽은 이중 뚜껑이다. Decocraft Dumpster는 실제 BBMODEL 40큐브로 대형 몸체·검정 뚜껑이 존재하여 종류/전체 비율은 비슷하지만 실제 게임용 원본 텍스처는 파란색이고 뚜껑도 검정 평판 하나처럼 보인다. 주황색 변형이나 2블록 설치 규칙은 검증되지 않았으므로 배색과 크기를 인정하지 않고 보류한다. 새 조합 텍스처를 직접 만들어 재배포하지 않는다.

### 076 — Chest / Small · 보류

![076 Chest PZ 왼쪽 MC 오른쪽](images/076_PZ_vs_MC.jpg)

PZ 원본은 손잡이와 잠금쇠가 있는 어두운 철제 소형 장방형 보관상자다. 기존 매칭은 실제 모델이 없는 상태였다. 새 Decocraft Lunch Box Black/Gray 역시 실제로는 도시락을 펼쳐 놓고 샌드위치·과자·음료가 바닥에 놓인 모양이므로 단순 금속 상자로 사용할 수 없다. 1.20.1 Forge Iron Chests에는 철제 보관함이 있지만 거기엔 이 원본과 같은 작은 휴대형 2:1 길이/양옆 손잡이가 있는지는 미확인.

### 077 — Microwave / Chrome · 조건부

![077 Microwave PZ 왼쪽 MC 오른쪽](images/077_PZ_vs_MC.jpg)

PZ는 검은 상판, 은회색 금속 본체, 왼쪽 어두운 창/사각 테두리, 오른쪽 버튼과 손잡이가 있는 전자레인지다. 기존 PFM Iron Microwave 렌더는 이상한 보라색 그림/분리된 큰 평판 때문에 완성형으로 볼 수 없다. 새 Decocraft Microwave는 실제 14큐브 원본 모델과 원본 텍스처를 모두 로드하여 앞 유리창·오른쪽 버튼·금속 하우징이 한 덩어리로 확인됨. 다만 MC 윗면은 밝은 회색이고 전면 조절부 비율이 다르며 게임 내 조리 기능은 검증되지 않았다.

### 078 — Counter / Wooden Corner · 보류

![078 Counter PZ 왼쪽 MC 오른쪽](images/078_PZ_vs_MC.jpg)

PZ는 전체 갈색 나무로 된 카운터에 안쪽 직각으로 도려낸 L자 코너 홈이 있다. 기존 Decocraft Diner Counter Corner Black은 검정/흰색 줄무늬 금속·45도 절단 바닥이라 종류가 틀리다. 새 Decocraft Bottom Cabinet Corner Inner Oak는 목재 몸체로 개선되지만 흰색 상판이고 렌더에 PZ 같은 안쪽 직각 홈이 확인되지 않는다. Outer 1/2 모델도 흰 상판/문 패널과 일부 보이지 않는 면 때문에 코너의 정확한 맞물림을 확인할 수 없다.

### 079 — Counter / Trailer · 보류

![079 Counter PZ 왼쪽 MC 오른쪽](images/079_PZ_vs_MC.jpg)

PZ는 밝은 나무톤 본체와 연베이지 상판을 가진 전면 양문형 하부장이다. 기존 Macaw Acacia Counter는 검은·붉은 큰 블록처럼 렌더되어 문 두 개가 전혀 확인되지 않는다. 새 Decocraft Bottom Cabinet 1 Oak는 색감은 근접하지만 위 서랍 1개+아래 문 1개이고 흰색 상판이라 원본의 두 문·베이지 상판과 다르다. Island Oak도 동일한 문제. 장치의 문 구조가 핵심이므로 승인하지 않는다.

### 080 — Oven / Grey · 조건부

![080 Oven PZ 왼쪽 MC 오른쪽](images/080_PZ_vs_MC.jpg)

PZ는 회색 은색 몸체, 검정 상판 위 둥근 화구 4개, 뒤쪽 금속 튐방지판, 검정 유리 오븐문을 가진다. 기존 PFM Gray Stove는 길쭉한 막대 1개만 나와 오븐이 아니었다. 새 Decocraft Stove 실제 98큐브 모델은 전체 은회색 바디, 사각격자형 검정 화구 4개, 전면 조절 노브, 검정 유리 오븐창으로 외형과 종류가 상당히 비슷하다. 하지만 PZ의 동그란 화구 모양·높은 백스플래시·오븐창 곡률은 다르다.

</details>

<details>
<summary><strong>081–090 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_081_090.md)

### 081 — Table / Fancy Low Glass · 보류

![081 Table PZ 왼쪽 MC 오른쪽](images/081_PZ_vs_MC.jpg)

PZ 완성형은 긴 타원형·가장자리가 둥글게 이어진 진갈색 목재 프레임과 투명 유리 상판을 지닌 낮은 2타일 테이블이다. 이전 Macaw Glass Table은 상판 평판 한 장만 남아 실제 장식 프레임과 다리 부분을 전혀 확인할 수 없다. 새 Cottage Coffee Table Oval의 19큐브 BBMODEL은 길쭉한 갈색 목재 낮은 테이블이지만 상판 전체가 불투명 목재이며 타원형 유리 인셋·곡선 테두리·하단 선반이 없어서 완성형과 다르다. Rattan Coffee Table도 직조 사각 상자라 불합격.

### 082 — Oak Round Table / 기본 · 보류

![082 Oak Round Table PZ 왼쪽 MC 오른쪽](images/082_PZ_vs_MC.jpg)

PZ 원본은 중간 갈색 원목 원형 상판과 갈색 중심 기둥·삼발이 다리다. 예전 Macaw Acacia Coffee Table은 짙은 회색 정사각 돌판처럼 렌더돼 전혀 어울리지 않았다. 새 Diner Table Round Black은 상판 원형과 한 기둥·삼발이 형태는 맞으나 실제 검정 금속 상판/회색 철제 다리로 목제 재질·색상이 반대다. Bamboo Round Yellow는 격자형 4다리라 더 다르다. 외형을 정확하게 유지하려면 목제 삼발이 모델을 찾아야 함.

### 083 — Wardrobe / Light Wood · 보류

![083 Wardrobe PZ 왼쪽 MC 오른쪽](images/083_PZ_vs_MC.jpg)

PZ는 밝은 갈색 두 문짝과 아래 서랍 2단(각 손잡이 2개)이 함께 있는 2칸 완성형 옷장이다. 기존 Macaw Acacia Double Wardrobe 렌더는 회색 나뭇결과 큰 붉은 문 일부만 나온 비정상 가구였다. 새 Decocraft Closet 6 Birch는 흰 나무색의 길고 가는 단문 옷장이며 하부 서랍이 아예 없다. Closet 2/4 Birch는 문 없이 옷이 걸린 열린 선반이고 Closet 3 Birch는 3단 서랍만 있다. 정확한 양문+2단 서랍 가구 미발견.

### 084 — Counter / Birchwood Corner · 보류

![084 Counter PZ 왼쪽 MC 오른쪽](images/084_PZ_vs_MC.jpg)

원본은 연갈색/벌꿀색 나무 코너 카운터로 오른쪽 뒤에 직각 홈이 있고 상판과 몸체가 거의 같은 계열의 갈색이다. 이전 Decocraft Diner Counter Corner Black은 줄무늬 검정 금속 카운터라 종류·재질 모두 틀렸다. 새 Bottom Cabinet Corner Inner Birch는 밝은 나무 몸체지만 상판이 새하얀 타일이고 렌더상 안쪽 L홈이 드러나지 않아 원본 같은 연결용 코너라고 확증할 수 없다. Outer 1/2도 동일한 상판·코너 결합 불확실성.

### 085 — Table / Large Brown · 보류

![085 Table PZ 왼쪽 MC 오른쪽](images/085_PZ_vs_MC.jpg)

PZ 원본은 2타일 길이의 짙은 갈색 원목 상판과 네 모서리에 곧게 내려가는 두꺼운 나무 다리 네 개뿐이다. 기존 Decocraft Table Setting Double은 테이블이 아니라 접시·컵 세트로 잘못 매칭되었다. 새 Decocraft Wooden Table Spruce는 갈색 나무 재질이 유사하지만 정사각형 1칸이며 다리에 장식 고리가 있고 두 개를 붙이면 중간에 다리가 중복될 가능성이 높다. Cottage Coffee Table Long은 낮은 커피 테이블이라 높은 식탁과 안 맞는다.

### 086 — Fancy Table / 기본 · 보류

![086 Fancy Table PZ 왼쪽 MC 오른쪽](images/086_PZ_vs_MC.jpg)

PZ 원본은 정사각 갈색 목제 프레임 안에 짙은 와인색/진갈색 직사각 인레이 상판이 구분되어 있고 네 다리와 모서리 장식이 보인다. 기존 Macaw Acacia Coffee Table는 회색 두꺼운 직사각 석판만 보여 틀렸다. 새 Decocraft Wooden Table Ebony는 어두운 목제 4다리와 정사각 비율은 있지만 상판이 한 가지 검정 나무색이며 중앙 이중 소재 패널·모서리 장식이 없다. Cottage Coffee Table도 단색 나무판이므로 원본 Fancy 구분 요소를 재현 못한다.

### 087 — Table / Large Smooth · 보류

![087 Table PZ 왼쪽 MC 오른쪽](images/087_PZ_vs_MC.jpg)

원본은 가로로 두 타일 합쳐진 크림/밝은 회색 길쭉한 가판 상판과 좌우 양끝의 철제 접이식 T형 받침대가 있는 테이블이다. 기존 Decocraft Table Setting Double는 접시·유리컵 세트일 뿐 테이블이 아니다. 새 Decocraft Diner Table Light Gray는 밝은 상판은 비슷하지만 1×1 정사각이고 중앙에 단 하나 금속 기둥·바닥판이 있어 양끝 T형 2다리 구조가 전혀 다르다. Wooden Table White는 흰 4개의 나무장식 다리로 역시 잘못된 유형이다.

### 088 — Combo Washer Dryer / Blue · 조건부

![088 Combo Washer Dryer PZ 왼쪽 MC 오른쪽](images/088_PZ_vs_MC.jpg)

PZ 원본은 파란 상판과 상부 파란 조작부, 아래 흰 네모 본체에 커다란 앞쪽 원형 세탁기 도어가 있는 콤보 세탁건조기다. 기존 Decocraft Washer 렌더는 전체 회색이라 사용자 구별점인 파란색이 사라지고 일부 모델만 보이는 것처럼 보여 원래 반려였다. 이번 실제 Decocraft Washer 30큐브 BBMODEL은 회색/흰 몸체·원형 유리 전면도어·위쪽 검정 조작부를 온전하게 보여 전체 구조가 비슷하다. 하지만 **파란 상판/파란 조작부가 아예 없고**, 게임에서 세탁+건조 둘 다 가능한지 확인하지 않아 조건부로만 유지한다.

### 089 — Antenna / Old TV · 보류

![089 Antenna PZ 왼쪽 MC 오른쪽](images/089_PZ_vs_MC.jpg)

PZ 이름 Antenna/Old TV는 TV 본체가 아니라 야외 지붕용 금속 Yagi형 안테나 두 벌을 하나의 세로 기둥에 단 물체다. 기존에 마크 후보가 없었고, 새 Decocraft TV Old를 직접 렌더해 보니 나무 케이스·화면·토끼귀 2개가 달린 소형 브라운관 TV로 원본의 긴 수십 개 금속 막대와 전혀 다른 물건이다. Simple Radio의 장식용 Antenna 및 J Radio의 여러 antenna tiers는 1.20.1 Forge 공개 설명에서 확인했지만 실제 Yagi 모양인지는 모델을 확보하지 않아 보류.

### 090 — Bed / Large Modern · 보류

![090 Bed PZ 왼쪽 MC 오른쪽](images/090_PZ_vs_MC.jpg)

PZ 원본은 2×2 큰 현대식 흰색 단색 침대 매트리스와 짙은 적갈색 나무 프레임, 막힌 넓은 목재 머리판과 발판 없는 박스형 침대틀이다. 기존 Decocraft Double Bed Birch Black는 밝은 세로살 나무 침대틀에 검정 체크 침구라 완전히 틀렸다. 새 Spruce White는 나무 프레임 색상과 흰 침구가 더 비슷하나 침구 전체가 회색 체크무늬, 분리된 베개가 돌출되고 머리판·발쪽 난간이 세로살 장식 구조라 가장 중요한 깨끗한 흰색·막힌 플랫 플랫폼 형태와 다르다. Black White/Oak White도 동일한 구조적 문제를 해결하지 못한다.

</details>

<details>
<summary><strong>091–100 (10종, 조건부 5 / 보류 5)</strong></summary>

[이 묶음만 보기](batches/BATCH_091_100.md)

### 091 — Television / Antique · 조건부

![091 Television PZ 왼쪽 MC 오른쪽](images/091_PZ_vs_MC.jpg)

PZ 원본은 1960년대 나무 프레임, 다리 네 개, 윗면 V자 토끼귀 안테나, 전면 왼쪽 화면과 오른쪽 세로 조절부가 있는 골동품 TV다. Decocraft TV Old 원본 30큐브 모델을 실제 Blockbench로 열었더니 나무 프레임/다리/V 안테나/측면 전면 조절 노브가 모두 나타나 기존 Decocraft CRT TV(검정 플라스틱 상자)보다 훨씬 정확하다. 다만 원본 화면은 어둡고 버튼은 세로로 더 작고, MC 모델의 나무톤이 조금 더 진하고 안테나 막대 굵기/각도 차이가 있어 최종 1:1은 아니다.

### 092 — Counter / Generic Shop · 보류

![092 Counter PZ 왼쪽 MC 오른쪽](images/092_PZ_vs_MC.jpg)

PZ는 상판과 몸체 모두 밝은 황갈색이며 앞면에 서랍·문·손잡이가 없는 매끈한 상점용 1칸 카운터다. 기존 Macaw Acacia Counter는 상판만 주황빛, 몸체는 어두운 회색/검정이라 다름. 새 Decocraft Bottom Cabinet 1 Birch/Oak는 목재 몸체는 더 가깝지만 흰 상판과 서랍 1개+손잡이 달린 아래 문이 노출되어 원본 단순한 앞판과 불일치. Diner Counter Yellow는 배포 모델 존재는 확인했지만 이 실행에서 렌더 검증 실패하여 비교 증거로 사용하지 않음.

### 093 — Bed / Fancy · 조건부

![093 Bed PZ 왼쪽 MC 오른쪽](images/093_PZ_vs_MC.jpg)

PZ는 두 개 타일의 검정 금속/목재 세로살 침대 프레임(머리판·발판)과 무늬 없는 크림빛 흰 침구로 구성된다. 기존 Decocraft Birch Black은 밝은 원목 프레임+검정 체크 침구로 색이 거꾸로였다. 새 Single Bed Black White 실제 29큐브 모델은 검정 세로살 머리판·발판, 흰 침구, 좁은 1인 침대 구조가 명확하게 일치하는 방향이다. 하지만 MC 침구가 흰 회색 체크무늬이고 커다란 흰 베개와 접힌 담요가 돌출돼, PZ의 매끈한 단색 매트리스와 차이. 1×2 타일 점유 역시 게임에서 미검증.

### 094 — Light Round Table / 기본 · 보류

![094 Light Round Table PZ 왼쪽 MC 오른쪽](images/094_PZ_vs_MC.jpg)

PZ는 밝은 나무 원형 상판 아래 갈색 중심 기둥 1개와 작게 뻗은 세 발이 있는 테이블. 기존 Macaw Acacia Coffee Table는 회색 사각 두꺼운 상판만 렌더돼 구조가 틀렸다. 새 Decocraft Bamboo Round Yellow는 밝은 노란 원형 상판이지만 높이가 낮고 옆면 십자 격자와 4개의 바깥 다리가 둘러싸기 때문에 기존 삼발이 목재 원형 식탁이 아니다. Diner Round Yellow도 금속 기둥+노란 플라스틱 상판이라 목재색과 다름.

### 095 — Round Table / 기본 · 보류

![095 Round Table PZ 왼쪽 MC 오른쪽](images/095_PZ_vs_MC.jpg)

PZ Round Table은 094와 구조가 거의 같지만 상판이 더 오렌지빛 갈색이며 다리도 같은 갈색 나무다. 기존 Macaw 회색 판은 유사성이 없다. 새 Decocraft Diner Table Round Yellow는 원형 상판·세발 받침이라는 기본 실루엣은 유사하지만 판은 노란 플라스틱이고 다리·기둥은 은회색 금속이라 원본 목재 재질과 오렌지톤이 맞지 않는다. 정확히 같은 가구로 승인하면 안 된다.

### 096 — Drawers / Mirror And · 조건부

![096 Drawers PZ 왼쪽 MC 오른쪽](images/096_PZ_vs_MC.jpg)

PZ 원본은 나무 서랍장(3단, 서랍당 검정 원형 손잡이 2개) 위에 곡선 상단의 세로 거울이 붙은 한 덩어리 화장대다. 기존 Macaw Bookshelf Drawer는 녹색 벽 판만 나온 부품 누락이고 거울이 없다. 새 Decocraft Vanity Left Birch의 실제 20큐브 원본 모델은 연목색 프레임, 큰 거울, 서랍 본체가 모두 일체형이어서 물건 유형을 올바르게 맞췄다. 다만 2단 서랍에 은색 긴 손잡이 하나씩이라 PZ의 3단/검정 손잡이 6개와 불일치, 거울 상단도 다각형이다. 더 닮은 모델을 찾기 전까지 조건부.

### 097 — Low Table / White · 보류

![097 Low Table PZ 왼쪽 MC 오른쪽](images/097_PZ_vs_MC.jpg)

PZ는 흰색/아이보리 낮은 사각 테이블로 윗판과 짧고 단순한 네 다리만 있다. 이전 Decocraft Bedside Table Open 1 White는 실제 파일에서 갈색 2단 서랍장이 펼쳐진 모습이라 전혀 다른 가구. 새 Decocraft Wooden Table White는 아이보리색 상판/네 다리는 있지만 **높이가 식탁급이고 굵은 장식 다리**가 있어 원본 낮은 테이블과 다르다. Cottage Coffee Table은 낮지만 짙은 갈색, Bamboo Square Yellow는 노랑 라탄 격자라 불일치.

### 098 — Toaster / Small Chrome · 조건부

![098 Toaster PZ 왼쪽 MC 오른쪽](images/098_PZ_vs_MC.jpg)

PZ는 손바닥만한 은회색 크롬 빵 토스터이며 윗면에 평행한 2개의 투입 슬롯, 둥근 모서리, 어두운 받침/측면 손잡이가 있다. 기존 Refurbished Dark Toaster의 불완전 검정 상자 렌더보다, 새 Decocraft Toaster Silver의 진짜 14큐브 원본은 은색 몸체·위 2개 슬롯·받침·모서리 깎임이 일치해서 외형이 상당히 근접한다. 그래도 PZ는 전면 좌하단 둥근 패널이 있고 MC는 각진 윗모서리라 완전 1:1은 아니며 설치 위치·음식 굽기 기능 확인 전.

### 099 — Chair / Pile o' Crepe · 보류

![099 Chair PZ 왼쪽 MC 오른쪽](images/099_PZ_vs_MC.jpg)

PZ 식당 의자는 선명한 주황 갈색 나무 좌석/다리 네 개와 등받이에 하나의 가로 나무대가 걸친 구조다. 기존 PFM Leather Armchair 렌더는 회색 한 판뿐이었고 팔걸이부터 물건 종류가 잘못되었다. Decocraft Chair 1 Cherry는 나무 4다리 형태는 맞지만 전체가 옅은 분홍빛이고 등받이에 여러 세로살이 있어 핵심적인 주황 나무색/가로대 1개와 다르다. School Chair Orange는 색상은 비슷하지만 주황 플라스틱+회색 금속 다리여서 재질이 다르고 Diner Chair Orange는 흰 줄무늬 플라스틱이라 불가.

### 100 — Table / Picknic · 조건부

![100 Table PZ 왼쪽 MC 오른쪽](images/100_PZ_vs_MC.jpg)

PZ 원본은 2×2 네 개 타일을 합쳐야 하는 나무 피크닉 테이블로 양쪽에 긴 좌석 두 개가 붙고 비스듬한 프레임 다리로 지지된다. 이전 Macaw Glass Table 렌더는 얇은 나무 평판 한 장이라 완전히 틀린 가구였다. 이번 Decocraft Picnic Table **실제 22큐브 BBMODEL을 전체 렌더**했더니 나무 상판+양쪽 2개 벤치+A형 경사 받침대가 함께 나타나 **완성형 전체 구조가 매우 유사**하다. 다만 PZ는 녹색 도색 금속/목재 다리인 데 반해 MC는 전부 밝은 목재이고 상판 판자 수·다리 색이 다르며, 2×2 칸을 차지하는지는 마크 게임에서 아직 검증하지 않았다. Benched 모드에도 2×2 실용 피크닉 벤치가 공식적으로 있으므로 추가 대안으로 남김.

</details>

<details>
<summary><strong>101–110 (10종, 조건부 5 / 보류 5)</strong></summary>

[이 묶음만 보기](batches/BATCH_101_110.md)

### 101 — Wardrobe / Fancy Oak · 보류

![101 Wardrobe PZ 왼쪽 MC 오른쪽](images/101_PZ_vs_MC.jpg)

PZ 원본은 짙은 적갈색 양문 옷장과 아래 서랍 2단(각 금빛 원형 손잡이 2개)을 합친 1×2 가구다. 원본 Decocraft BBMODEL 렌더를 실제 확인하니 Closet 5 Ebony(8큐브)는 정면이 열린 등나무 바구니/선반 형태이며 옷장 문 자체가 없다. Closet 6 Oak(11큐브)는 좁은 단문 밝은 목재 옷장으로 하부 서랍이 전혀 없다. 기존 Macaw Dark Oak Double Wardrobe는 상단 상태 일부만 보였으므로 모두 반려한다.

### 102 — Cabinet / Grey File · 조건부

![102 Cabinet PZ 왼쪽 MC 오른쪽](images/102_PZ_vs_MC.jpg)

원본은 짙은 회색 철제 세로형 3단 파일 캐비닛이다. 기존 Refurbished 회색 주방 수납장은 전면 서랍이 없는 불완전한 상자여서 반려. Decocraft White Filing Cabinet의 실제 원본 렌더에서는 3개의 서랍, 라벨 틀, 가로 손잡이가 모두 보여 구조가 상당히 가깝지만 표면은 밝은 백색에 가까워 원본의 중간 회색 금속과 차이가 크다. 검정 변형도 회색이 아니므로 조건부다.

### 103 — Counter / Shop Display · 보류

![103 Counter PZ 왼쪽 MC 오른쪽](images/103_PZ_vs_MC.jpg)

PZ 원본은 밝은 베이지 목재의 1칸 진열대로 윗면에 두꺼운 사각 목재 테두리와 안쪽으로 파인 연회색 진열 공간이 있고 앞·옆면에는 서랍이나 문이 없다. 실제 렌더한 Decocraft Display Counter Bottom Oak(6큐브)는 베이지 목재 몸체는 비슷하지만 상판이 회색 금속/석재의 완전히 평평한 뚜껑으로 덮여 있으며 테두리 안쪽 오목한 공간이 없다. White 변형은 몸체까지 백색이다. 기존 Macaw Acacia Counter의 붉은 상판/검은 몸체도 부적합하므로 보류.

### 104 — Couch / Brown Lazy · 조건부

![104 Couch PZ 왼쪽 MC 오른쪽](images/104_PZ_vs_MC.jpg)

PZ 원본은 짙은 붉은 갈색 가죽의 2인용 소파로 양끝 둥근 팔걸이, 두 좌석 쿠션, 분할된 부드러운 등받이가 있다. 실제 Decocraft Couch Left Leather Brown(6큐브)과 Right Leather Brown(6큐브)은 갈색 가죽 질감과 좌우 각 1개 팔걸이를 가진 별개 모듈이므로 두 개를 붙이면 기본 소파 유형이 맞는다. 그러나 모델은 PZ보다 밝은 주황 갈색, 팔걸이와 등받이가 각진 평판이며 2×1 완성 연결/중간 경계는 게임에서 확인하지 않았다. 기존 Macaw Brown Couch는 한쪽 모듈만 렌더돼 완성형을 재현하지 못했다.

### 105 — Table / Large Plastic · 보류

![105 Table PZ 왼쪽 MC 오른쪽](images/105_PZ_vs_MC.jpg)

PZ 원본은 2×1 흰색 플라스틱 접이식 긴 테이블로 중앙 상판 접합선과 어두운 금속 U자형 다리 2쌍/가로 보강대가 보인다. 기존 Decocraft table_setting_double은 접시와 컵만 렌더돼 테이블이 아니다. 새 Wooden Table White(25큐브)는 흰 목재의 굵고 장식된 다리 4개를 가진 일반 식탁이며, Diner Table Light Gray(12큐브)는 회색 판 아래 중앙 금속 기둥 1개가 있는 카페 테이블이다. 모두 원본의 접이식 다리 구조와 2칸 긴 상판을 재현하지 못해 보류한다.

### 106 — Public Garbage Bin / 기본 · 보류

![106 Public Garbage Bin PZ 왼쪽 MC 오른쪽](images/106_PZ_vs_MC.jpg)

PZ 원본은 검은 철제 원통형 공공 쓰레기통으로 세로 철살 몸통과 방사형으로 벌어진 상단 테두리, 중앙의 열린 원형 투입구가 특징이다. Decocraft Trash Can(59큐브)은 녹슨 은회색 아연도금 원통에 손잡이 달린 닫힌 평평한 뚜껑이 있다. Trash Can Open(60큐브)은 뚜껑이 옆으로 젖혀지고 검은 쓰레기봉투가 드러나며, 어느 쪽도 PZ의 방사형 원형 투입구가 아니다. 기존 Paladin Mesh Trashcan은 사각형 그물망과 초록색 윗면으로 완전히 달라 반려한다.

### 107 — Chair / Brown Lazy · 조건부

![107 Chair PZ 왼쪽 MC 오른쪽](images/107_PZ_vs_MC.jpg)

PZ 원본은 104번과 같은 짙은 붉은 갈색 가죽의 1인용 안락의자로 둥근 높은 등받이와 두꺼운 양쪽 팔걸이, 넓은 좌석 쿠션이 있다. Decocraft Armchair Leather Brown의 원본 9큐브 모델을 실제 렌더했으며 두 팔걸이, 좌석, 등받이, 아래 가죽 받침이 모두 완전하게 나타나 의자 유형이 맞는다. 하지만 마크 모델은 더 밝은 주황 갈색이고 각진 직선 등받이/팔걸이로 원본의 둥근 쿠션형 실루엣과 다르다. Cottage Armchair는 꽃무늬 천이라 재질·색 모두 불일치한다.

### 108 — Microwave / White · 조건부

![108 Microwave PZ 왼쪽 MC 오른쪽](images/108_PZ_vs_MC.jpg)

PZ 원본은 크림색/백색 소형 전자레인지로 왼쪽 어두운 전면 창, 오른쪽 세로 조작부가 있다. 새 Decocraft Microwave(14큐브) 원본 BBMODEL을 Blockbench로 확인하니 본체·검정 유리문·오른쪽 버튼 격자·아래 다이얼까지 완전하게 나타난다. 이전 Refurbished Dark Microwave의 녹색 기둥 하나짜리 부분 렌더보다 확실히 낫다. 다만 새 모델 몸체는 회색 금속이고 전면 버튼·다이얼이 PZ와 달라 색상/세부 외형은 조건부로 남긴다.

### 109 — Piano / Western · 조건부

![109 Piano PZ 왼쪽 MC 오른쪽](images/109_PZ_vs_MC.jpg)

PZ 원본은 2×1 적갈색 서부풍 업라이트 피아노로 검은색/흰색 건반과 아래 금빛 페달 3개, 둥근 옆판이 있다. 실제 Decocraft Piano Upright Spruce(56큐브)는 가로로 긴 업라이트 목재 본체, 검은/흰 건반, 3개 금빛 페달이 전부 갖춰져 외형이 상당히 유사하다. 하지만 PZ보다 밝은 갈색이며 큰 흰 악보판, 직선적 사각 프레임과 하단 다리가 달라 조건부다. 별도 렌더한 Piano Spruce(245큐브)는 뚜껑을 연 그랜드 피아노이므로 구조상 대체할 수 없다.

### 110 — Shelves / Hardwood Wall · 보류

![110 Shelves PZ 왼쪽 MC 오른쪽](images/110_PZ_vs_MC.jpg)

원본은 진갈색 목재 판자 2개가 벽에 간격을 두고 수평으로 붙은 단순 벽 선반이다. 기존 Handcrafted Acacia Shelf 렌더는 양옆 벽과 뒷판이 있는 두꺼운 책장형 상자여서 구조가 다르다. 현재 확인된 원본 모델 목록에서 같은 높이의 독립된 판자 2개를 한 블록 안에 배치하는 완성형 가구를 찾지 못했다. 마크 다크오크 덫문 2개를 벽에 펼쳐 만드는 방법은 바닐라 재현안일 뿐 실제 한 칸 배치는 미검증이다.

</details>

<details>
<summary><strong>111–120 (10종, 조건부 2 / 보류 8)</strong></summary>

[이 묶음만 보기](batches/BATCH_111_120.md)

### 111 — Bed / Large Fancy · 조건부

![111 Bed PZ 왼쪽 MC 오른쪽](images/111_PZ_vs_MC.jpg)

원본 PZ는 검정 세로살 머리판·발판과 흰색 단색 매트리스가 핵심이다. 기존 Birch Black은 밝은 원목 프레임에 검정 체크 침구라 색 배합이 반대다. Decocraft Double Bed Black White는 검정 프레임과 흰 침구라는 방향은 맞지만 회백색 체크무늬와 커다란 흰 베개/접힌 이불이 두드러져 원본의 평평한 단색 침구와 다르다. 2×2 설치·수면 기능은 인증하지 않는다.

### 112 — Fridge / Mini · 보류

![112 Fridge PZ 왼쪽 MC 오른쪽](images/112_PZ_vs_MC.jpg)

PZ 원본은 손잡이와 도어 분할선이 거의 보이지 않는 검정 무광 직육면체 미니 냉장고다. 기존 Refurbished Dark Fridge는 부분 모델 가져오기에서 분홍 측면/검정 전면으로 잘못 보였다. 이번 Decocraft Fridge Small Black 원본 293큐브를 Blockbench 5.2.2로 직접 렌더하니 위아래 2개 문, 은색 손잡이 2개, 상단 통풍구가 있는 높고 큰 가정용 냉장고였다. PZ의 짧고 단순한 검정 미니 냉장고와 문 수·높이·외관이 달라 보류한다.

### 113 — Bin / Washing · 보류

![113 Bin PZ 왼쪽 MC 오른쪽](images/113_PZ_vs_MC.jpg)

PZ 원본은 노란 천 자루를 회색 금속 사각 프레임에 걸어 둔 세탁물 수거함이다. 이번 Decocraft Laundry Basket Rattan의 실제 20큐브 렌더는 갈색 등나무 뚜껑이 달린 사각 바구니로 천과 금속 프레임이 없다. Rolling Bin Yellow의 실제 41큐브 렌더는 검정 뚜껑·바퀴 달린 노란 플라스틱 쓰레기통이다. 둘 다 원본의 구조/소재가 달라 보류한다.

### 114 — Box / Cartboard · 보류

![114 Box PZ 왼쪽 MC 오른쪽](images/114_PZ_vs_MC.jpg)

원본은 위쪽을 갈색 테이프로 봉한 작은 종이 골판지 택배 상자다. 기존 Refurbished Acacia Mail Box는 길고 높은 우편함이라 전혀 맞지 않는다. 기존 5개 모드의 실제 등록 블록에서는 같은 카드보드 상자를 찾지 못했다. 공식 Forge 1.20.1을 지원하는 CardboardBox 및 Cardboard Boxes 모드를 추가 발견했지만 해당 JAR의 3D 모델을 아직 렌더링하지 않아 후보 확정은 보류한다.

### 115 — Drawers / Dark Fancy · 조건부

![115 Drawers PZ 왼쪽 MC 오른쪽](images/115_PZ_vs_MC.jpg)

PZ 원본은 검정 무광 단순 2단 서랍장으로 위아래 서랍에 짧은 은색 가로 손잡이가 하나씩 달린다. 기존 Macaw Acacia Bookshelf Drawer는 선반의 초록 판만 표시되어 반려한다. 이번 Decocraft Modular Desk Drawers Black의 실제 50큐브 Blockbench 모델은 검정 목재, 서랍 2개, 은색 손잡이 2개가 확인되어 구조·색상에서 가장 가깝다. 하지만 다리 네 개가 길고 장식이 많으며 상판이 두껍고 원본보다 높은 듯해 조건부다. Bedside Table Black은 ID와 달리 렌더에서 갈색 목재로 보여 선택 텍스처/원본 모델 표현을 추가 검증해야 한다.

### 116 — Table / Large Dark Oak · 보류

![116 Table PZ 왼쪽 MC 오른쪽](images/116_PZ_vs_MC.jpg)

PZ 원본은 적갈색 단순 2×1 긴 사각 테이블로 얇은 평평한 상판과 직선 다리 네 개를 가진다. 기존 Macaw Dark Oak Glass Table은 유리 상판 한 장만 표시돼 반려한다. 이번 Decocraft Wooden Table Ebony 25큐브는 정사각형에 가까운 매우 짙은 갈색 상판과 두꺼운 장식 다리, Kitchen Table Ebony 29큐브는 검정 상판과 두꺼운 장식 다리, Wooden Table Cherry는 분홍색 상판과 장식 다리로 각각 원본의 긴 직사각형·적갈색·곧은 다리 구조와 다르다. 멀티타일 2×1 설치 여부도 미검증이므로 보류한다.

### 117 — Fridge / Industrial · 보류

![117 Fridge PZ 왼쪽 MC 오른쪽](images/117_PZ_vs_MC.jpg)

PZ 원본은 검은 산업용 냉장 진열장으로 전면의 큰 투명 유리문과 내부 가로 선반, 세로 손잡이가 핵심이다. Decocraft Fridge Large 실제 372큐브 모델은 은색 4문 불투명 가정용 냉장고이고, 문을 활짝 연 Fridge Large Open Full에서만 내부 선반이 보인다. Vending Machine Soda 200큐브 모델은 음료 진열창과 선반이 있지만 우드색 전면·동전/버튼 패널을 가진 자동판매기로 냉장고와 다르다. 검정 유리문 진열장과 일치하지 않아 보류한다.

### 118 — Fridge / White Industrial · 보류

![118 Fridge PZ 왼쪽 MC 오른쪽](images/118_PZ_vs_MC.jpg)

PZ 원본은 117번과 같은 산업용 유리문 냉장 진열장이지만 흰색/연회색 외장, 청록빛 투명 문과 내부 선반, 검정 받침대를 가진다. 기존 Paladin White Fridge는 불투명 문과 통풍 그릴이 있어 부적합. 이번 Decocraft Fridge Large 372큐브는 은색 불투명 4문이고 Fridge Small Silver 293큐브는 은색 2문 가정용 모델이며 Open Top Silver는 문을 열어 놓은 변형일 뿐 닫힌 투명 유리문이 아니다. 모두 보류한다.

### 119 — Television / Premium Technologies · 보류

![119 Television PZ 왼쪽 MC 오른쪽](images/119_PZ_vs_MC.jpg)

PZ 원본은 Facing W의 뒷면/측면이 보이는 회색 쐐기형 CRT TV로 후면 가로 통풍구와 주황 표시등이 관찰된다. 기존 Refurbished Television은 정육면체 전면 검정 패널로 윤곽이 다르다. 이번 Decocraft CRT TV 실제 12큐브 모델은 검정 정육면체에 가까운 화면 상자로 회색 사다리꼴 후면과 다르며, TV Small/Wall Small은 평면형 모니터라 두께와 형태가 더욱 다르다. 같은 방향에서 후면을 비교한 인게임 회전 검증도 없으므로 보류한다.

### 120 — Counter / Modern Corner · 보류

![120 Counter PZ 왼쪽 MC 오른쪽](images/120_PZ_vs_MC.jpg)

PZ 원본은 베이지색 L자 상판의 안쪽 모서리가 파여 있고 아래는 진한 황갈색 목재 판넬로 이어지는 1칸 코너 카운터다. 기존 Decocraft Diner Corner Black은 검정·은색 띠와 대각 챔퍼로 부적합. 이번 Decocraft Bottom Cabinet Corner Inner Oak 9큐브는 흰 정사각형 상판과 밝은 갈색 큐브 몸체, Inner Ebony는 검정 상판과 거의 검정 몸체로 나타났다. Outer 1 Oak 23큐브는 부분 삼각형 상판 조각일 뿐 1×1 오목 L자 전체가 아니다. 어느 것도 원본의 베이지 L자 홈과 진한 목재색을 동시에 갖추지 않아 보류한다.

</details>

<details>
<summary><strong>121–130 (10종, 조건부 2 / 보류 8)</strong></summary>

[이 묶음만 보기](batches/BATCH_121_130.md)

### 121 — Fridge / Steel · 보류

![121 Fridge PZ 왼쪽 MC 오른쪽](images/121_PZ_vs_MC.jpg)

원본은 은회색 단일 전면판과 왼쪽 검정 세로 경계가 두드러지는 좁은 냉장고다. 실제 Decocraft Fridge Small Silver 원본 293큐브는 위·아래 두 문이 가로선으로 분리되고 전면에 은색 가로 손잡이 두 개와 상부 통풍구가 있어 외형이 다르다. Fridge Large 372큐브는 좌우 양문·디스펜서까지 있는 넓은 최신형이라 더 멀다. 이전 Paladin Iron Fridge는 이 묶음에서 실제 완성 모델 검증을 하지 않았으므로 승인하지 않는다.

### 122 — Counter / Bar · 보류

![122 Counter PZ 왼쪽 MC 오른쪽](images/122_PZ_vs_MC.jpg)

원본은 상판·몸체·하단 몰딩이 모두 짙은 나무이며 서랍·손잡이·흰 조리대가 없다. 실제 Decocraft Bottom Cabinet 1 Spruce/Oak 13큐브를 열어 보니 두 모델 모두 흰색 두꺼운 상판, 앞쪽 상부 서랍 및 손잡이, 하부 문이 나타나 원본 바 카운터와 다르다. Diner Counter Yellow는 원본 파일이 있지만 이번 실행에서 Blockbench 모델 큐브 3개로 완성 렌더 판정을 받지 못해 비교 증거로 쓰지 않는다.

### 123 — Chair / Fancy White · 보류

![123 Chair PZ 왼쪽 MC 오른쪽](images/123_PZ_vs_MC.jpg)

원본의 핵심은 위로 둥글게 올라간 전통형 등받이, 부드러운 곡면 팔걸이, 얇게 드러난 어두운 나무 다리 네 개다. 실제 Decocraft Armchair Cream 9큐브는 크림색이 가깝지만 직선 평판 등받이와 네모 팔걸이·바닥까지 막힌 몸체로 구조가 크게 다르다. Cottage Armchair 23큐브는 꽃무늬와 아래 천 스커트가 있어 원본 단색 우아한 의자와 더 다르다. 색만 맞았다는 이유로 승인하지 않는다.

### 124 — Fridge / White · 조건부

![124 Fridge PZ 왼쪽 MC 오른쪽](images/124_PZ_vs_MC.jpg)

원본은 위쪽 작은 냉동실과 아래쪽 큰 냉장실로 구분된 따뜻한 아이보리 2도어 냉장고다. Decocraft Fridge Small Cream 실제 293큐브 모델은 크림색 세로 직육면체, 위아래 2도어 분할이라는 중요한 실루엣이 일치한다. 다만 마크 모델에는 앞쪽 수평 은색 손잡이 두 개, 상단 4개 통풍구, 각진 윗모서리가 뚜렷하며 PZ는 옆면 세로 손잡이와 더 매끈한 면이다. 실물 외형은 조건부이며 게임 설치/냉장 기능은 확인하지 않았다.

### 125 — Chair / Beach · 조건부

![125 Chair PZ 왼쪽 MC 오른쪽](images/125_PZ_vs_MC.jpg)

원본은 나무 접이식 프레임과 하늘색·흰색 줄무늬 천이 연결된 낮은 비치 체어다. 실제 Decocraft Beach Chair Light Blue 원본 18큐브를 Blockbench로 렌더하니 흰색/하늘색 세로 줄무늬 천, 비스듬한 목재 등받이, 앞쪽으로 내려오는 좌석, 뒤 지지대가 모두 존재해 이전 Paladin Arm Chair Leather의 회색 세로판보다 훨씬 정확하다. Blue 변형은 줄무늬가 진한 남색이어서 PZ 밝은 파랑보다 멀다. PZ 프레임 각도·다리의 교차 위치·천 굴곡은 일부 다르고 실제 1×2 설치 여부는 미검증이다.

### 126 — Chair / Green Comfy · 보류

![126 Chair PZ 왼쪽 MC 오른쪽](images/126_PZ_vs_MC.jpg)

PZ는 노란 기가 도는 올리브 천, 낮고 둥근 등받이, 쿠션 굴곡, 아래쪽 짙은 적갈색 받침이 특징이다. Decocraft Armchair Green 실제 9큐브 모델은 진한 녹색 직선 평판 등받이·각진 팔걸이·바닥까지 같은 녹색 몸체이며 둥근 쿠션과 목재 받침이 없다. Lime은 훨씬 선명한 연두라 색상도 다르다. 가구 분류만 같고 핵심 실루엣·재질이 달라 보류한다.

### 127 — Counter / Oak Corner · 보류

![127 Counter PZ 왼쪽 MC 오른쪽](images/127_PZ_vs_MC.jpg)

원본은 상판에 안쪽으로 파인 직각 ㄱ자 홈이 보이는 한 칸짜리 전체 원목 코너 카운터다. Decocraft Corner Inner Oak 실제 9큐브는 흰 상판을 가진 정사각형 캐비닛으로 홈이 없고, Corner Outer 2 Oak 실제 21큐브는 흰 상판+서랍·손잡이가 붙은 사다리꼴 모서리 부품이다. 둘을 임의로 합쳐 원본 1×1 ㄱ자 가구라고 간주할 근거가 없으므로 보류한다.

### 128 — Counter / White Corner · 보류

![128 Counter PZ 왼쪽 MC 오른쪽](images/128_PZ_vs_MC.jpg)

원본은 ㄱ자로 안쪽이 파인 상판과 몸체 전체가 아이보리색인 단순한 코너 카운터다. 실제 Decocraft Corner Outer 1 White 23큐브는 상판이 갈색 나무이고 몸체는 얇은 패널 조각이라 한 덩어리 가구가 아니다. Corner Inner White 9큐브도 나무색 정사각 상판에 흰 몸체인 평범한 정육면체로 ㄱ자 홈이 없다. 기존 후보의 색·형상·부품 완결성이 모두 달라 보류한다.

### 129 — Chair / Light Blue · 보류

![129 Chair PZ 왼쪽 MC 오른쪽](images/129_PZ_vs_MC.jpg)

PZ 이름은 Light Blue지만 실제 완성형 미리보기는 회색에 가까운 아주 옅은 청록빛 천과 둥근 등받이·쿠션을 가진 낮은 안락의자다. 실제 Decocraft Armchair Light Blue 9큐브는 채도 높은 밝은 파랑, Ocean Blue는 더 짙은 청록이며 둘 다 각진 높은 평판 등받이와 직각 팔걸이, 아래 받침이 없는 일체형이다. 이전 Paladin Blue Arm Chair 역시 검푸른 단순 L형 판으로 맞지 않았다. 색과 실루엣 차이가 커 보류한다.

### 130 — Couch / Light Blue · 보류

![130 Couch PZ 왼쪽 MC 오른쪽](images/130_PZ_vs_MC.jpg)

원본은 회청색 2인 소파가 2×1로 이어지고 둥근 등받이와 좌석 쿠션이 중앙에서 구분된다. Decocraft Couch Left/Right Light Blue 원본을 각각 Blockbench로 열어 보니 좌·우 팔걸이가 있는 모듈은 실제로 존재하지만 마크의 선명한 파랑이 PZ의 회색에 가까운 색보다 진하고, 등받이는 직선 평판이며 원본의 쿠션 굴곡·하단 받침이 없다. 두 소스 모델을 한 게임에서 연결해 확인한 것도 아니므로 완성형 2인 소파로 승인하지 않는다.

</details>

<details>
<summary><strong>131–140 (10종, 조건부 2 / 보류 8)</strong></summary>

[이 묶음만 보기](batches/BATCH_131_140.md)

### 131 — Freezer / Chest · 보류

![131 Freezer PZ 왼쪽 MC 오른쪽](images/131_PZ_vs_MC.jpg)

PZ 원본은 높이가 낮고 위로 열리는 크림색 상자형 냉동고이며 상단 금속 걸쇠와 아래쪽 측면 통풍구가 보인다. 기존 Refurbished Dark Freezer 자동 렌더는 검은 앞면과 목재색 측면의 부품 한 개만 나타나 완성형을 확인할 수 없었다. 이번 Decocraft Fridge Small Cream/Silver 모델은 실제 293큐브 완성형이지만 높이 큰 전면 2도어 냉장고라 구조가 완전히 다르다. 비슷한 색이라는 이유로 채택하지 않는다.

### 132 — Fridge / Build-in Trailer · 보류

![132 Fridge PZ 왼쪽 MC 오른쪽](images/132_PZ_vs_MC.jpg)

PZ 원본은 트레일러 가구와 일체인 작은 은색 냉장고 문 한 장, 양옆 황갈색 목재 프레임, 윗쪽 넓은 나무 상판이다. 기존 Refurbished Dark Fridge 렌더는 분홍색 높은 냉장고의 일부 그래픽으로 원본과 다르다. 이번 Decocraft Small Cream/Silver Open 냉장고는 상하 2도어의 세로형 프리즘이고 내부에 음식이 보이는 열린 상태라 PZ의 낮은 1도어 목재 내장형 가구가 아니다.

### 133 — Chair / Black Fancy · 보류

![133 Chair PZ 왼쪽 MC 오른쪽](images/133_PZ_vs_MC.jpg)

PZ는 짙은 갈색/검정 천 또는 가죽의 부드러운 높은 곡선 등받이, 둥근 쿠션 팔걸이, 밑으로 노출된 가느다란 갈색 목제 다리 네 개를 갖춘 고전식 안락의자다. 기존 Paladin Black Arm Chair는 검정 직각 의자처럼 보여 원본의 다리·곡선 쿠션이 없다. 새 Decocraft Armchair Black/Dark Gray/Leather Brown 원본 모델을 모두 확인해도 각진 등받이·직선 팔걸이·바닥까지 막힌 함체 구조라 핵심 형태가 달라 보류한다.

### 134 — Oven / Green · 보류

![134 Oven PZ 왼쪽 MC 오른쪽](images/134_PZ_vs_MC.jpg)

PZ 원본은 녹회색/민트색 에나멜 오븐으로 같은 초록색 굽은 뒷판, 둥근 화구 4개와 전면 조작 노브, 둥근 오븐창이 연결된다. 새 Decocraft Stove는 98큐브 온전한 금속 오븐과 화구는 있으나 완전히 은색/회색이며 위의 화구가 사각형 가스 레인지형이고 초록색 뒷판이 전혀 없다. Decocraft Toilet Mint는 녹색만 비슷하고 변기이므로 가구 종류가 다르다. 실제 같은 녹색 오븐 모델을 찾기 전까지 보류한다.

### 135 — Bed / Simple · 보류

![135 Bed PZ 왼쪽 MC 오른쪽](images/135_PZ_vs_MC.jpg)

PZ 원본은 나무 4다리와 낮은 평평한 베이스에 무늬 없는 크림색 직사각 매트리스 하나만 얹힌 간단 침대이고, 높은 머리판·발치 울타리가 없다. 이전 Decocraft Bunk Bed Birch Black 렌더는 2층 침대라 명백한 오매칭. 새 Single Bed Oak/Spruce White 실제 BBMODEL은 단층이지만 침대 머리와 발끝에 높은 세로살 목재 울타리와 체크무늬 매트리스/분리 베개가 있어 소박한 원본과 크게 달라; 후보 승인 불가.

### 136 — Bench / Birchwood · 보류

![136 Bench PZ 왼쪽 MC 오른쪽](images/136_PZ_vs_MC.jpg)

원본은 2타일 길이의 회갈색 노후 목재 판자 3줄과 바닥에 고정되는 회색 철제 T자 지지대 3개를 가진 등받이 없는 공원 벤치다. 기존 Handcrafted Birch Bench는 빨간 등받이 쿠션이 붙은 1인 의자 부품으로 나와 오매칭. 새 Decocraft Piano Bench Spruce/White는 단일 1칸, 목재 다리 4개, 철제 받침 없는 피아노 의자이고 Picnic Table은 탁자까지 있는 구조여서 정확한 가구가 아니다.

### 137 — Chair / White Lazy · 조건부

![137 Chair PZ 왼쪽 MC 오른쪽](images/137_PZ_vs_MC.jpg)

원본은 누런 크림색 천이 있는 통통한 1인 안락의자, 좌우 두꺼운 팔걸이와 두툼한 좌석 쿠션, 바닥까지 내려오는 스커트형 몸체다. Decocraft Armchair Cream 실제 원본 모델은 크림색, 넓은 팔걸이와 낮은 박스형 본체의 구성이 비슷해 기존 Paladin Oak Chair Classic White (의자 다리 두 개와 분홍 막대만 보이던 불완전 렌더)보다 훨씬 낫다. 다만 마크는 등받이가 높은 각진 평판이고 팔걸이도 직선이며 원본의 부드럽고 둥근 쿠션과 층진 스커트가 없다. 조건부 후보만.

### 138 — Toilet / Low · 보류

![138 Toilet PZ 왼쪽 MC 오른쪽](images/138_PZ_vs_MC.jpg)

PZ Low Toilet는 일반 도기 양변기처럼 큰 물통이 없고, 열린 낮은 둥근 변기 볼 뒤쪽으로 긴 금속 수직 봉과 십자 손잡이·배수 장치가 드러나는 구식 화장실 설비다. 기존 Paladin Basic Toilet은 커다란 사각 물통이 있고, 이번 Decocraft Toilet White/Aqua도 물통과 위로 세워진 뚜껑이 있는 보통 양변기다. 낮은 볼+노출 금속 봉의 모양이 빠져 있어 부적합으로 보류.

### 139 — Counter / Floating Trailer · 조건부

![139 Counter PZ 왼쪽 MC 오른쪽](images/139_PZ_vs_MC.jpg)

PZ는 트레일러 내부 벽에 설치된 황갈색 2도어 수납장이고 위에 같은 나무색 상판이 있다. 새 Decocraft Top Cabinet 3 Oak 실모델은 목재 색감, 두 개의 틀 있는 전면 문과 가벼운 낮은 높이, 윗면 나무판이 가까워 기존 Macaw Acacia Counter의 붉은 상판+검은 단색 직육면체 오매칭보다 좋다. 다만 PZ는 각 문에 아래쪽 작은 원형 손잡이가 있고 MC에는 중앙에 긴 은회색 손잡이 하나처럼 보이며 방향/벽 부착·1칸 설치는 검증되지 않았다. 조건부만.

### 140 — Couch / Blue Comfy · 보류

![140 Couch PZ 왼쪽 MC 오른쪽](images/140_PZ_vs_MC.jpg)

PZ는 탁한 남청색 패브릭 두 칸 소파로 양끝에 둥근 말린 팔걸이가 있고 등받이 위쪽도 긴 원통형 쿠션이 연결되는 형태다. 기존 Macaw Blue Couch는 밝은 파란색 직각 1좌석만 렌더되어 완성형 2칸 근거가 없다. 새 Decocraft Couch Left/Right Ocean Blue와 Light Blue를 실제 BBMODEL로 각각 렌더해 2모듈 구성은 확인했지만 모두 박스형 평평한 등받이, 직선 팔걸이이고 원본 둥근 롤쿠션·어두운 색감이 다르다. 게임에서 실제 접속도 확인되지 않았으므로 보류.

</details>

<details>
<summary><strong>141–150 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_141_150.md)

### 141 — Couch / White Lazy · 보류

![141 Couch PZ 왼쪽 MC 오른쪽](images/141_PZ_vs_MC.jpg)

기존 Macaw White Couch는 흰 직각형 단일 소파 조각만 렌더되어 2좌석 완성형이 아니며 색·목재 하단 프레임이 없다. Decocraft Couch Left/Right Light Blue 실모델은 연결 가능한 좌우 모듈 형태지만 파란색 단색 직각 쿠션과 직선 팔걸이라 크림색+목재 팔걸이 원본과 다르다. 좌우 게임 내 접속도 미검증.

### 142 — Counter / Green · 보류

![142 Counter PZ 왼쪽 MC 오른쪽](images/142_PZ_vs_MC.jpg)

기존 Decocraft Diner Counter Corner Green은 초록+흰색 수평 줄무늬가 있는 각진 모서리 바/기둥으로 전면 문 두 개와 손잡이가 없어 오매칭. Decocraft Bottom Cabinet 1 Oak는 수납장 종류는 가깝지만 원목색, 문/서랍 구성과 상판색이 달라 정확한 대체가 아니다.

### 143 — Dumpster / Blue · 조건부

![143 Dumpster PZ 왼쪽 MC 오른쪽](images/143_PZ_vs_MC.jpg)

기존 Decocraft Rolling Bin Blue는 높고 좁은 1인용 바퀴 달린 수거통이어서 2×1 대형 덤프스터와 종류가 다름. 원본 Decocraft Dumpster BBMODEL의 기존 네이티브 Blockbench 렌더에서 검정 다중 리브 뚜껑, 파란 금속 직사각 몸체, 측면 손잡이와 오염 흔적이 확인되어 훨씬 가깝다. 다만 PZ는 더 보랏빛이며 뚜껑 패널 수/경사, 2×1 설치 범위는 차이가 있고 실제 게임에서 미검증이므로 조건부만.

### 144 — Fridge / Plain · 보류

![144 Fridge PZ 왼쪽 MC 오른쪽](images/144_PZ_vs_MC.jpg)

기존 Refurbished Dark Fridge 부분 렌더는 분홍색 측면과 검정 앞면만 보여 원본의 크림색 전면 통풍 격자/아래 제어칸이 없다. Decocraft Small Cream도 일반 상하 두 문 냉장고로 원본 통풍 전면 구조와 다르다.

### 145 — Counter / Low Motel · 보류

![145 Counter PZ 왼쪽 MC 오른쪽](images/145_PZ_vs_MC.jpg)

기존 Macaw Acacia Counter는 주황색 상판과 검은 전체 높이의 블록형 받침이 있어 원본의 벽 부착형 얇은 판과 다르다. Decocraft Bathroom Counter Left White도 수납형 전체 가구로 원본의 빈 하부 공간을 재현하지 못한다.

### 146 — Chair / Blue Comfy · 보류

![146 Chair PZ 왼쪽 MC 오른쪽](images/146_PZ_vs_MC.jpg)

기존 Paladin Blue Arm Chair는 밝은 청색 직각 등받이·한 좌석 블록으로 원본의 둥근 팔걸이/두툼한 쿠션/짙은 색을 재현하지 못한다. Decocraft Cottage Armchair는 곡선형 쿠션과 팔걸이는 가깝지만 꽃무늬 분홍·크림 패턴이라 원본의 단색 회청색과 큰 차이.

### 147 — Couch / Green Comfy · 보류

![147 Couch PZ 왼쪽 MC 오른쪽](images/147_PZ_vs_MC.jpg)

기존 Macaw Green Couch는 밝은 초록색 직각 1좌석만 보여 2인 완성형과 다르다. Decocraft Couch Left/Right Ocean Blue는 좌우 모듈 구조는 있지만 푸른 색감, 평평한 각진 팔걸이와 등받이로 PZ의 올리브색 롤쿠션·하단 목재 베이스가 없다.

### 148 — Low Table / Long · 보류

![148 Low Table PZ 왼쪽 MC 오른쪽](images/148_PZ_vs_MC.jpg)

기존 Macaw Acacia Coffee Table의 렌더는 회색 낮은 평판만 보여 갈색 나뭇결·다리·2×1 길이가 모두 다름. Decocraft Piano Bench Spruce는 갈색 평판+다리 구조는 있지만 좌판용 좁은 벤치이며 원본 테이블 상판의 폭·길이와 다를 수 있어 검증된 대체가 아님.

### 149 — Shelves / Lightwood Wall · 보류

![149 Shelves PZ 왼쪽 MC 오른쪽](images/149_PZ_vs_MC.jpg)

기존 Handcrafted Acacia Shelf 네이티브 렌더는 전면에 큰 구멍 두 개가 있는 전체 높이 나무 캐비닛 형태로 원본의 얇은 한 장 선반과 다름. Decocraft Top Cabinet 3 Oak도 두 문이 있는 상부 수납장이라 단순 판자 한 장을 대신하지 못한다.

### 150 — Wardrobe / Fancy White · 보류

![150 Wardrobe PZ 왼쪽 MC 오른쪽](images/150_PZ_vs_MC.jpg)

기존 Macaw Acacia Double Wardrobe는 짙은 회색 목재 몸체와 주황 문 두 개가 있는 직각 옷장으로 흰색 몰딩/하단 두 서랍이 없다. Decocraft Bottom Cabinet 2 White는 흰색 수납장 계열이지만 낮은 주방 하부장이라 높은 옷장과 두 서랍 구성에 부적합.

</details>

<details>
<summary><strong>151–160 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_151_160.md)

### 151 — Radio / ValuTech · 보류

![151 Radio PZ 왼쪽 MC 오른쪽](images/151_PZ_vs_MC.jpg)

No actual MC radio source/model found in existing inspected candidate list; do not invent a radio model

### 152 — Shower / Deluxe · 보류

![152 Shower PZ 왼쪽 MC 오른쪽](images/152_PZ_vs_MC.jpg)

MC render shows only a small rectangular red/grey handle, not tray, plumbing or shower head

### 153 — Shelves / Beige Rack Shop · 보류

![153 Shelves PZ 왼쪽 MC 오른쪽](images/153_PZ_vs_MC.jpg)

MC single orange/brown blocky shelf has solid sides and no continuous 4x1 open rack geometry

### 154 — Barbecue / Charcoal · 보류

![154 Barbecue PZ 왼쪽 MC 오른쪽](images/154_PZ_vs_MC.jpg)

MC partial render is separated tall grey post and black cuboid; no red dome, kettle bowl or tripod

### 155 — Counter / White Floating · 보류

![155 Counter PZ 왼쪽 MC 오른쪽](images/155_PZ_vs_MC.jpg)

MC model is an open white bathroom counter with wood top and visible shelves/bottles; not a closed hanging cabinet

### 156 — Shelves / Corner A · 보류

![156 Shelves PZ 왼쪽 MC 오른쪽](images/156_PZ_vs_MC.jpg)

MC orange closed boxy cubby is not three open protruding shelves; left/right geometry unverified

### 157 — Shelves / Corner B · 보류

![157 Shelves PZ 왼쪽 MC 오른쪽](images/157_PZ_vs_MC.jpg)

Same MC candidate reused for opposite PZ end; cannot encode both handed variants as shown

### 158 — Shelves / Middle · 보류

![158 Shelves PZ 왼쪽 MC 오른쪽](images/158_PZ_vs_MC.jpg)

MC full orange solid cabinet/shelf body with thick top and sides, not open center piece

### 159 — Table / Large Dark Wooden · 보류

![159 Table PZ 왼쪽 MC 오른쪽](images/159_PZ_vs_MC.jpg)

MC proof renders a pale flat glass-textured plane, no dark wooden top or legs; partial model

### 160 — Table / Pool · 조건부

![160 Table PZ 왼쪽 MC 오른쪽](images/160_PZ_vs_MC.jpg)

MC has recognisable matching felt/wood/legs/pockets but visible coloured racked balls and cue ball; prior MC model bounds ~3x2 blocks versus PZ 2x1

</details>

<details>
<summary><strong>161–170 (10종, 조건부 2 / 보류 8)</strong></summary>

[이 묶음만 보기](batches/BATCH_161_170.md)

### 161 — Hamster Wheel / Human · 조건부

![161 Hamster Wheel PZ 왼쪽 MC 오른쪽](images/161_PZ_vs_MC.jpg)

PZ 완성형과 Decocraft Treadmill 원본 BBMODEL 모두 러닝 벨트·전면 콘솔·좌우 손잡이·지지대가 있는 같은 가구 유형이다. 다만 PZ는 은회색 프레임/검정 벨트, Minecraft는 거의 전체가 검정이고 콘솔과 벨트 비례가 다르다. 기존 Casino Wheel 자동 후보는 가구 종류 자체가 달라 반려한다. 구조가 가까운 조건부 대안만.

### 162 — Locker / Blue Wall · 보류

![162 Locker PZ 왼쪽 MC 오른쪽](images/162_PZ_vs_MC.jpg)

Decocraft Locker Blue 실제 원본은 색과 금속 캐비닛 높이, 통풍구는 비슷하지만 큰 문 하나, 긴 외부 손잡이 하나, 상단 이름표가 있다. PZ의 두 개 문과 각 매립 손잡이 구조가 빠져 있다. 동일한 1×1 블록에 두 문을 표현할 수 있는지 확인 전까지 보류.

### 163 — Bench / Sturdy · 보류

![163 Bench PZ 왼쪽 MC 오른쪽](images/163_PZ_vs_MC.jpg)

PZ는 긴 밝은 목재 외장·갈색 쿠션·한쪽 긴 측판이 있는 1×2 벤치다. 실제 Decocraft Gym Bench BBMODEL(7큐브) Blockbench 화면은 검정색 금속 운동기구의 왼쪽 일부만 나타나며, 긴 나무 외장과 등받이/쿠션이 없다. 화면 밖 잘림 또는 원본 모델의 파트 누락 가능성까지 있어 완성형 대체로 인증할 수 없다.

### 164 — Bench / Foot · 보류

![164 Bench PZ 왼쪽 MC 오른쪽](images/164_PZ_vs_MC.jpg)

PZ는 회색 평판 상판과 두 개의 가느다란 검정 금속 U자 프레임으로 된 1×1 낮은 발받침이다. Decocraft Gym Bench 원본 7큐브 렌더는 검은 체육기구의 한쪽만 나타나 회색 상판·U자 지지대 두 개와 맞지 않는다. 163번 목재 벤치와 동일 MC ID를 부여한 자동 매칭은 형태를 구분하지 못한 오류다.

### 165 — Desk / Lightwood · 보류

![165 Desk PZ 왼쪽 MC 오른쪽](images/165_PZ_vs_MC.jpg)

PZ는 2×1 밝은 목재의 긴 책상으로, 서랍 없는 평판 상판과 양 끝 두 개의 넓은 판자 다리가 보인다. 기존 Macaw Acacia Covered Desk 자동 캡처는 검은 수직 판자 하나만 보여 불완전하다. 새로 원본 Decocraft Modular Desk Drawers Oak BBMODEL(50큐브)을 Blockbench로 렌더했더니 작은 1×1 목재 서랍장(전면 은색 손잡이 두 개)이며 긴 상판·양끝 판자 다리·열린 하부 공간이 전혀 없다. 따라서 새 후보도 반려한다.

### 166 — Sink / Large Industrial · 보류

![166 Sink PZ 왼쪽 MC 오른쪽](images/166_PZ_vs_MC.jpg)

PZ는 스테인리스 산업용 독립 싱크대(깊은 금속 볼, 4개의 금속 다리, 아래 철제 선반, 높게 굽은 스프링 분무 호스)다. 기존 Paladin Basic Sink 부분 렌더는 노란 수평판만 나타났다. 새로 Decocraft Kitchen Sink Silver 원본 BBMODEL(23큐브)을 실제 렌더한 결과 흰색 도기 사각 싱크와 짧은 고정형 수전만 있으며 금속 4다리·하부 선반·산업용 호스가 없다. 색·재질·구조가 달라 반려한다.

### 167 — Stool / Piano · 조건부

![167 Stool PZ 왼쪽 MC 오른쪽](images/167_PZ_vs_MC.jpg)

기존 Macaw Acacia Stool Chair 캡처는 얇은 상판만 보여 다리 4개와 완성형 벤치 구조가 누락됐다. Decocraft Piano Bench Spruce의 실제 원본 Blockbench 화면은 등받이 없는 짙은 갈색 평판 좌판과 네 개 목재 다리를 완전하게 보여 PZ와 외형 종류가 유사하다. 그러나 PZ는 2×1이며 Minecraft 모델의 실제 설치 길이/좌판 비율과 색감은 다를 수 있어 조건부만.

### 168 — Bed / Blue · 보류

![168 Bed PZ 왼쪽 MC 오른쪽](images/168_PZ_vs_MC.jpg)

Decocraft Single Bed Birch Blue 실제 BBMODEL은 같은 단층 침대이고 파란 이불이 있지만 높은 세로살 머리판과 발치 울타리, 흰 베개와 체크무늬 짙은 남색 이불을 포함한다. PZ의 단순한 민무늬 회청색 매트리스와 평판 머리판/발치 무울타리 구조가 달라 색상 유사만으로 승인하지 않는다.

### 169 — Fridge / Green · 보류

![169 Fridge PZ 왼쪽 MC 오른쪽](images/169_PZ_vs_MC.jpg)

기존 Refurbished Dark Fridge Blockbench 캡처는 분홍색 측면과 검은 전면의 일부 그래픽으로만 보이며 PZ의 초록색 두 문 냉장고 완성형을 보여주지 못한다. Decocraft Small Cream은 두 칸 구조만 비슷하고 색이 크림색이며 PZ의 레트로 곡면과 경첩/손잡이 위치가 달라 보류.

### 170 — Industrial 2000 / Fryers Club · 보류

![170 Industrial 2000 PZ 왼쪽 MC 오른쪽](images/170_PZ_vs_MC.jpg)

기존 7개 모드 JAR의 자동 매칭 결과에는 검증된 실제 Minecraft 모델이 없다. 이름 Industrial 2000을 일반 오븐으로 대체하면 깊은 튀김조·배수/온도조절 패널·산업용 다리 구조가 사라지므로 후보를 임의 생성하거나 승인하지 않는다.

</details>

<details>
<summary><strong>171–180 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_171_180.md)

### 171 — Oven / Red · 보류

![171 Oven PZ 왼쪽 MC 오른쪽](images/171_PZ_vs_MC.jpg)

기존 decocraft:pizza_oven 네이티브 렌더는 벽돌 화덕+굴뚝+장작형 불구멍이며 PZ 붉은 전기레인지의 금속 본체, 버너, 다이얼, 오븐문이 모두 없다. 화덕을 전기레인지로 승인할 수 없다.

### 172 — Wardrobe / White · 보류

![172 Wardrobe PZ 왼쪽 MC 오른쪽](images/172_PZ_vs_MC.jpg)

기존 Macaw Acacia Double Wardrobe는 회색 외장/주황 문으로 원본과 색이 정반대. 새 후보 Decocraft White Bottom Cabinet은 밝은 색은 유사해도 높이가 낮은 주방장으로 높은 옷장과 문/손잡이 배치가 다르다.

### 173 — Chair / Spiffos Dinner · 보류

![173 Chair PZ 왼쪽 MC 오른쪽](images/173_PZ_vs_MC.jpg)

기존 pfm:arm_chair_leather 네이티브 비교는 회색 직육면체 일부만 보이는 불완전 모델이라 좌석 형태를 확인할 수 없다. Decocraft Diner Chair Blue는 다리/등받이/좌판 재질·색·중앙 받침 구조가 다른 일반 의자 후보여서 1:1 아님.

### 174 — Clothing Dryer / White · 보류

![174 Clothing Dryer PZ 왼쪽 MC 오른쪽](images/174_PZ_vs_MC.jpg)

Blockbench 5.2.2에서 새로 렌더한 Decocraft Dryer는 전면 상단 디지털 화면·왼쪽 다이얼, 전면의 사선 큰 손잡이와 각진 패널이 확인된다. PZ는 뒤쪽 상단으로 솟은 검은 제어판과 전면 왼쪽의 작은 세로 손잡이, 단순 직사각형 문을 가진다. 같은 건조기 계열이지만 조작부 위치·도어/손잡이 구조가 달라 1:1 승인 불가.

### 175 — Oven / Industrial · 보류

![175 Oven PZ 왼쪽 MC 오른쪽](images/175_PZ_vs_MC.jpg)

기존 Decocraft Pizza Oven은 벽돌 화덕과 굴뚝이 있는 전혀 다른 종류. 추가 스테인리스 주방 설비 후보 Kitchen Sink Silver도 싱크대이므로 조리 그릴·오븐문·높은 측면 판을 재현하지 못한다. 후보 불승인.

### 176 — Counter / Generic Shop Corner · 보류

![176 Counter PZ 왼쪽 MC 오른쪽](images/176_PZ_vs_MC.jpg)

Decocraft Diner Counter Corner Black은 L형 상판과 코너 체적은 비슷하지만 검정·흰색 가로 줄무늬 금속/플라스틱 바 형태로 나무 질감·색상과 일치하지 않는다.

### 177 — Counter / Dark · 보류

![177 Counter PZ 왼쪽 MC 오른쪽](images/177_PZ_vs_MC.jpg)

기존 Macaw Acacia Counter는 주황 상판+회색 석재 측면으로 원본과 재질 불일치. Decocraft Bottom Cabinet 2 Oak는 수납장 계열이지만 밝은 참나무 색과 문·서랍 배치가 달라 어두운 2도어 카운터 대체로 승인 불가.

### 178 — Chair / Red Theatre · 보류

![178 Chair PZ 왼쪽 MC 오른쪽](images/178_PZ_vs_MC.jpg)

기존 Paladin Oak Chair Classic Red는 막대 프레임 일부만 렌더되어 의자 전체를 입증하지 못한다. 새 Decocraft Cottage Armchair는 꽃무늬 쿠션과 크고 둥근 양팔걸이의 1인 가정용 의자이며, PZ 극장식 붉은 등받이/검정 금속 다리·연결형 구조와 다르다. PZ 좌석 개수는 추가 확인이 필요하다.

### 179 — Drawers / Pale · 보류

![179 Drawers PZ 왼쪽 MC 오른쪽](images/179_PZ_vs_MC.jpg)

새 Blockbench 원본 렌더에서 Decocraft Modular Desk Drawers Oak는 전면 두 개의 큰 서랍, 돌출 회색 손잡이 두 개, 장식된 네 기둥/다리로 구성된다. PZ는 밝은 베이지 직육면체에 세 개의 얇은 수평 서랍과 돌출 손잡이 없는 평면이므로 서랍 수·손잡이·프레임이 명백히 다르다.

### 180 — Counter / Birchwood Floating · 보류

![180 Counter PZ 왼쪽 MC 오른쪽](images/180_PZ_vs_MC.jpg)

기존 Macaw Birch Counter는 흰 회색 석재 본체+나무 상판의 바닥 설치 블록이어서 원본과 다름. Decocraft Top Cabinet 3 Oak는 벽 부착형 주방 수납장 종류지만 문 분할, 손잡이 수, 길이와 상판 색상 일치가 검증되지 않아 확정 불가.

</details>

<details>
<summary><strong>181–190 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_181_190.md)

### 181 — Deluxe / Espresso · 보류

![181 Deluxe PZ 왼쪽 MC 오른쪽](images/181_PZ_vs_MC.jpg)



### 182 — Counter / Bar Corner · 보류

![182 Counter PZ 왼쪽 MC 오른쪽](images/182_PZ_vs_MC.jpg)



### 183 — Counter / Cantina Food · 보류

![183 Counter PZ 왼쪽 MC 오른쪽](images/183_PZ_vs_MC.jpg)



### 184 — Cabinet / China · 보류

![184 Cabinet PZ 왼쪽 MC 오른쪽](images/184_PZ_vs_MC.jpg)



### 185 — Counter / Oakwood Floating · 보류

![185 Counter PZ 왼쪽 MC 오른쪽](images/185_PZ_vs_MC.jpg)



### 186 — Locker / Green Wall · 보류

![186 Locker PZ 왼쪽 MC 오른쪽](images/186_PZ_vs_MC.jpg)



### 187 — Shelves / Generic Cooled · 보류

![187 Shelves PZ 왼쪽 MC 오른쪽](images/187_PZ_vs_MC.jpg)



### 188 — Shower / Wall · 보류

![188 Shower PZ 왼쪽 MC 오른쪽](images/188_PZ_vs_MC.jpg)



### 189 — Wardrobe / Dark Fancy · 보류

![189 Wardrobe PZ 왼쪽 MC 오른쪽](images/189_PZ_vs_MC.jpg)



### 190 — Counter / Spiffos · 보류

![190 Counter PZ 왼쪽 MC 오른쪽](images/190_PZ_vs_MC.jpg)



</details>

<details>
<summary><strong>191–200 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_191_200.md)

### 191 — Desk / Medical · 보류

![191 Desk PZ 왼쪽 MC 오른쪽](images/191_PZ_vs_MC.jpg)

실제 PZ 완성형과 기존 mcwfurnitures:acacia_covered_desk Blockbench 화면을 비교하면 오른쪽에는 책상 전체가 아닌 세로 목재판 한 장만 보인다. 검정 긴 상판·우측 2문 수납장·1×3 조립 근거가 모두 빠져 원본 후보는 부적합.

### 192 — Counter / Steel Floating · 보류

![192 Counter PZ 왼쪽 MC 오른쪽](images/192_PZ_vs_MC.jpg)

PZ는 금속 벽걸이 이중문 캐비닛인데 기존 mcwfurnitures:acacia_counter 렌더는 갈색 상판과 어두운 목재의 바닥형 카운터. 재질·문·벽면 부착 방식·높이 모두 불일치.

### 193 — Jukebox / Oldies · 조건부

![193 Jukebox PZ 왼쪽 MC 오른쪽](images/193_PZ_vs_MC.jpg)

PZ 완성형과 Decocraft jukebox의 원본 BBMODEL을 Blockbench 5.2.2로 재렌더한 화면(50 cubes)을 직접 대조했다. 둘 다 빈티지 주크박스이고 아치형 상단·전면 장식·하단 캐비닛이 있지만, Minecraft는 민트·노랑·빨강 네온과 나무 측면, PZ는 회색 둥근 돔과 초록색 하단/검정 전면이다. 크기·음악 재생·1:1 외형은 미검증이므로 조건부만.

### 194 — Chair / Modern White · 보류

![194 Chair PZ 왼쪽 MC 오른쪽](images/194_PZ_vs_MC.jpg)

PZ는 폭이 넓은 천 쿠션형 암체어인데 기존 pfm:oak_chair_classic_white 네이티브 캡처에는 두 나무 기둥과 분홍 가로막대만 보이며 쿠션·좌판·등받이·팔걸이 전체가 빠져 있다. 부분 모델은 대체 근거로 부적합.

### 195 — Counter / Motel · 보류

![195 Counter PZ 왼쪽 MC 오른쪽](images/195_PZ_vs_MC.jpg)

기존 mcwfurnitures:acacia_counter는 붉은 상판과 어두운 목재로 PZ 크림색 이중문 캐비닛과 다르다. 추가로 Decocraft bottom_cabinet_2_white의 실제 원본 BBMODEL 11 cubes를 Blockbench로 새로 렌더한 결과, 흰색 몸통과 밝은 상판은 비슷하나 전면에 수평 손잡이 달린 서랍 4개가 있고 PZ의 세로 여닫이문 2개·황동색 둥근 손잡이 2개가 없다. 따라서 추가 후보도 반려.

### 196 — Shelves / Trapzoid Shop · 보류

![196 Shelves PZ 왼쪽 MC 오른쪽](images/196_PZ_vs_MC.jpg)

PZ 원본은 두 개의 위로 열린 목재 진열 바구니인데 기존 handcrafted:acacia_shelf 네이티브 화면은 갈색 직육면체 측면에 검은 사각 개구부 두 개가 있는 캐비닛 형태. 진열 상자 깊이·측판·전면 구조가 불일치.

### 197 — Contraption / Fitness · 보류

![197 Contraption PZ 왼쪽 MC 오른쪽](images/197_PZ_vs_MC.jpg)

PZ는 검정 쿠션 벤치에 높은 은회색 바벨 거치 기둥 2개가 달린 1×2 벤치프레스 기구다. Decocraft gym_bench 실제 원본 BBMODEL 7 cubes를 Blockbench 5.2.2로 새로 렌더했지만 화면에는 검은 좌판과 한쪽 지지대 일부만 보이고 바벨 거치대 2개가 확인되지 않는다. 원본 모델 전체가 캡처되었는지도 불확실하여 승인하지 않는다.

### 198 — Stand / Pool Cue · 보류

![198 Stand PZ 왼쪽 MC 오른쪽](images/198_PZ_vs_MC.jpg)

PZ 원본은 금색 장식이 있는 얇은 갈색 벽걸이 판자형 큐 스탠드지만 Decocraft pool_rack 실제 원본 BBMODEL 59 cubes의 재렌더는 바닥형 넓은 나무 랙과 여러 큐대·삼각대·컬러 볼 진열을 보여준다. 종류는 연관되어도 폭·깊이·벽 부착 여부·물체 수가 달라 기존 조건부 판정을 보류로 하향한다.

### 199 — Shelves / Large Rental · 보류

![199 Shelves PZ 왼쪽 MC 오른쪽](images/199_PZ_vs_MC.jpg)

PZ 조립 미리보기에는 길고 높은 밝은 베이지색 판 구조가 보이는데 handcrafted:acacia_shelf 원본 렌더는 작은 짙은 적갈색 1블록 선반 캐비닛으로 색상·비율·길이·전면 구조가 다르다. PZ 뒷면이 보이는지 추가 시점 확인 필요.

### 200 — Bench / Sports · 보류

![200 Bench PZ 왼쪽 MC 오른쪽](images/200_PZ_vs_MC.jpg)

PZ는 2×1 길이의 밝은 목재 좌판과 은회색 금속 다리 3개가 있는 스포츠 벤치다. Decocraft gym_bench 실제 원본 BBMODEL 7 cubes 재렌더는 검은 운동기구 좌판과 한쪽 다리 일부만 보여 목재 재질·세 지지대·2블록 길이와 맞지 않는다. 197 헬스기구와 200 목재 벤치를 같은 Minecraft gym_bench로 자동 매칭한 오류를 확인했다.

</details>

<details>
<summary><strong>201–210 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_201_210.md)

### 201 — Fireplace / 기본 · 보류

![201 Fireplace PZ 왼쪽 MC 오른쪽](images/201_PZ_vs_MC.jpg)

PZ 원본 완성형을 직접 확인했으며 기존 357종 비교판에는 실제 Minecraft 모델이 없고 'MOD FURNITURE NOT VERIFIED'로 표시된다. 원본 자산을 확인하지 않은 상태에서 벽난로 모델을 임의 지정하지 않는다.

### 202 — Oven / Large Modern · 보류

![202 Oven PZ 왼쪽 MC 오른쪽](images/202_PZ_vs_MC.jpg)

PZ 원본은 은색 스테인리스 2단 전기 오븐과 전면 검정 유리문 2개·좌측 조작 패널이다. 공식 Blockbench 5.2.2에서 실제 Decocraft pizza_oven BBMODEL 31 cubes를 다시 렌더해 확인했으나 붉은 벽돌 화덕, 높은 벽돌 굴뚝, 둥근 입구와 불꽃, 삽이 있는 완전히 다른 장치다. 2×1 점유와 전기 오븐 기능도 일치하지 않아 보류.

### 203 — Table / Large Dark · 보류

![203 Table PZ 왼쪽 MC 오른쪽](images/203_PZ_vs_MC.jpg)

기존 decocraft:table_setting_double 렌더는 접시·컵·수저만 있는 식기 장식이다. 새로 실제 Blockbench에서 diner_table_black(12 cubes)을 열어 보니 어두운 직사각 상판은 유사하지만 은색 테두리와 중앙 단일 금속 받침/넓은 발판이며 PZ의 짙은 목재 상판·네 모서리 가는 다리와 다르다. wooden_table_oak(25 cubes)도 네 다리 구조는 있으나 밝은 참나무 정사각 상판과 굵고 장식적인 다리로 PZ의 2×1 짙은 긴 테이블과 다르다.

### 204 — Chair / Makeshift · 보류

![204 Chair PZ 왼쪽 MC 오른쪽](images/204_PZ_vs_MC.jpg)

기존 pfm:arm_chair_leather 네이티브 캡처는 회색 판 한 장만 보이는 부분 모델이다. 새 Decocraft school_chair_gray 원본 BBMODEL 37 cubes를 Blockbench로 렌더한 결과 얇은 회색 금속 네 다리, 평평한 금속 좌판과 분리된 회색 등받이의 교실 의자다. PZ의 두꺼운 거친 목재 널빤지 좌판, 판재 바닥 받침 및 짧은 판자 등받이와 형태·재질·높이가 불일치.

### 205 — Shelves / Zippee Wall · 보류

![205 Shelves PZ 왼쪽 MC 오른쪽](images/205_PZ_vs_MC.jpg)

기존 handcrafted:acacia_shelf의 실제 Blockbench 렌더는 두 개의 검은 개구부가 있는 두꺼운 적갈색 박스형 캐비닛이다. PZ의 개방형 얇은 2단 흰색 벽 선반과 재질·색상·깊이·부착 구조가 다르다.

### 206 — Table / Lightwood Trailer · 보류

![206 Table PZ 왼쪽 MC 오른쪽](images/206_PZ_vs_MC.jpg)

기존 mcwfurnitures:acacia_glass_table 네이티브 캡처는 얇은 나무판 한 장만 보이는 부분 렌더다. 새 Decocraft kitchen_table_oak BBMODEL 29 cubes는 흰색 상판과 밝은 참나무의 굵은 4다리 식탁으로 확인했다. PZ는 베이지색 모서리 둥근 1×2 길이 상판과 중앙 금속 기둥 2개이므로 상판 색·모서리·다리 수·재질·길이 모두 불일치.

### 207 — Barbecue / Jorge Foreguy · 조건부

![207 Barbecue PZ 왼쪽 MC 오른쪽](images/207_PZ_vs_MC.jpg)

기존 refurbished_furniture:black_grill 캡처는 부분 소스만 보여 완성형 근거가 없다. 새로 Decocraft grill_black 원본 BBMODEL 70 cubes를 Blockbench 5.2.2로 열어 확인하니 검정 가스그릴 몸체, 양쪽 갈색 목재 보조 선반, 회색 프레임, 하부 선반이 PZ와 구조적으로 유사하다. 그러나 Minecraft는 뚜껑이 열린 검정색이며 내부 음식과 가스통이 보이고, PZ는 은회색 닫힌 둥근 뚜껑과 측면 바퀴가 있으며 Decocraft 화면에는 바퀴가 보이지 않는다. 따라서 1:1 승인 없이 조건부 후보만 유지한다.

### 208 — Chair / Modern Red · 보류

![208 Chair PZ 왼쪽 MC 오른쪽](images/208_PZ_vs_MC.jpg)

기존 pfm:oak_chair_classic_red의 Blockbench 캡처는 갈색 수직 막대 2개와 연녹색 가로막대 1개뿐이며 빨간 쿠션·좌판·등받이가 없다. 부분 소스 로딩으로 보이므로 외형 일치 판정에 사용할 수 없다.

### 209 — Chair / Yellow Modern · 보류

![209 Chair PZ 왼쪽 MC 오른쪽](images/209_PZ_vs_MC.jpg)

기존 pfm:froggy_chair_yellow 네이티브 캡처는 노란 평판 한 장뿐이다. 새 Decocraft bamboo_chair_yellow BBMODEL 30 cubes의 실제 렌더는 노란빛 대나무/라탄 짜임 좌판, X자 등받이, 높은 나무 네 다리, 팔걸이 없는 개방형 의자다. PZ의 두꺼운 겨자색 패브릭 팔걸이·쿠션 등받이·낮은 다리 1인 소파와 전혀 다르다.

### 210 — Counter / Dark Corner · 보류

![210 Counter PZ 왼쪽 MC 오른쪽](images/210_PZ_vs_MC.jpg)

실제 Decocraft diner_counter_corner_black BBMODEL 11 cubes를 공식 Blockbench 5.2.2로 재렌더한 결과, 검정색 본체에 흰색/은색 가로 줄무늬가 반복되고 전면 모서리가 둥글게 꺾이는 다이너 카운터다. PZ는 어두운 갈색 나뭇결, 장식 없는 평평한 상판과 직각 안쪽 홈이 있는 L자 목재 코너다. 색·재질·모서리 및 인접 카운터 연결이 달라 보류.

</details>

<details>
<summary><strong>211–220 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_211_220.md)

### 211 — Dish / Satellite · 보류

![211 Dish PZ 왼쪽 MC 오른쪽](images/211_PZ_vs_MC.jpg)

PZ는 흰 접시형 위성 안테나와 수신 암·벽면 브래킷, MC는 목제 접시 건조대와 그릇이다. Dish라는 영어 동음이의어만 일치하며 용도·형상·벽 부착 모두 다름.

### 212 — Freezer / Popsicle · 보류

![212 Freezer PZ 왼쪽 MC 오른쪽](images/212_PZ_vs_MC.jpg)

PZ는 1×2 수평형 연회색 ICE 냉동고·상단 유리 미닫이 뚜껑 2장, MC는 검정 전면문과 갈색 측판의 세로형 1블록 냉동고 부분 렌더다.

### 213 — Fridge / Large · 보류

![213 Fridge PZ 왼쪽 MC 오른쪽](images/213_PZ_vs_MC.jpg)

PZ는 2×1 검정 산업용 평판 냉장고·하단 통풍 그릴, MC는 은색 4문 가정용 냉장고·손잡이·정수기. 기존 조건부 판정을 외형 불일치로 보류로 변경한다.

### 214 — Microphone / Standing · 조건부

![214 Microphone PZ 왼쪽 MC 오른쪽](images/214_PZ_vs_MC.jpg)

둘 다 검정색 수직 스탠드 위에 기울어진 마이크가 있다. PZ의 세 갈래 삼각 받침·가느다란 마이크 목과 MC의 팔각 원형 받침·굵은 헤드가 다르므로 외형 조건부만 인정한다.

### 215 — Table / Long · 보류

![215 Table PZ 왼쪽 MC 오른쪽](images/215_PZ_vs_MC.jpg)

PZ는 진갈색 목재 직사각 상판·4개의 가는 다리, MC는 밝은 아카시아색 납작한 부분 렌더만 표시돼 다리·높이·길이가 누락됐다.

### 216 — Table / Long Dark · 보류

![216 Table PZ 왼쪽 MC 오른쪽](images/216_PZ_vs_MC.jpg)

PZ는 흑갈색 긴 목제 상판·4다리, MC는 215번과 동일한 밝은 아카시아색 납작한 부분 렌더라 다리·어두운 색·두께가 누락됐다.

### 217 — Counter / Glass Display · 보류

![217 Counter PZ 왼쪽 MC 오른쪽](images/217_PZ_vs_MC.jpg)

PZ는 검정 받침 위 투명 유리 3면·유리 상판·금속 프레임의 진열 카운터, MC는 불투명 나무 몸통과 주황 상판의 일반 카운터다.

### 218 — Shelves / Comics Shop · 보류

![218 Shelves PZ 왼쪽 MC 오른쪽](images/218_PZ_vs_MC.jpg)

PZ는 회색 금속 3단 개방 선반과 초록·노랑 만화가게 광고 패널, MC는 적갈색 목제 2칸 박스 선반이다.

### 219 — Shelves / Long · 보류

![219 Shelves PZ 왼쪽 MC 오른쪽](images/219_PZ_vs_MC.jpg)

PZ는 4조각을 이은 1×4 긴 밝은 목재 3단 선반, MC는 1×1 적갈색 2칸 박스 선반으로 길이·층수·개방도·색·멀티타일 조립이 다르다.

### 220 — Barbecue / Full Jorge Foreguy · 보류

![220 Barbecue PZ 왼쪽 MC 오른쪽](images/220_PZ_vs_MC.jpg)

PZ는 은색 곡면 뚜껑·검정 본체·전면 노브·좌우 선반·바퀴의 가스 바비큐, MC 부분 JSON 렌더는 회색 막대와 검정 블록만 보여 완성 모델 증거가 아니다.

</details>

<details>
<summary><strong>221–230 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_221_230.md)

### 221 — Chair / Purple Rattan · 보류

![221 Chair PZ 왼쪽 MC 오른쪽](images/221_PZ_vs_MC.jpg)

PZ는 낮고 둥근 갈색 라탄 팔걸이·분홍 쿠션의 실내 암체어다. 기존 pfm:oak_chair_classic_purple Blockbench 캡처는 기둥 2개와 청록 가로대만 있는 불완전 모델이었다. 새로 Decocraft beach_chair_purple 원본 BBMODEL 18 cubes를 공식 Blockbench 5.2.2에서 렌더하니 보라·흰색 줄무늬 천이 늘어진 긴 야외 접이식 덱체어, 가느다란 밝은 목재 경사 프레임으로 확인됐다. 등나무 양팔걸이·두꺼운 분홍 쿠션·낮은 사각 몸체가 없어 보류.

### 222 — Chair / Red Comfy · 보류

![222 Chair PZ 왼쪽 MC 오른쪽](images/222_PZ_vs_MC.jpg)

PZ는 두꺼운 적색 통쿠션과 양팔걸이, 낮은 네 발이 있는 실내 암체어다. 기존 pfm:oak_chair_classic_red는 불완전 기둥 2개/가로대만 보였다. 새 Decocraft beach_chair_red 원본 BBMODEL 18 cubes를 Blockbench 5.2.2에서 렌더하니 빨강·흰색 줄무늬 천과 가는 나무 경사 프레임을 가진 접이식 야외 덱체어였다. 패딩·양팔걸이·사각 실내 암체어 구조가 모두 다르다.

### 223 — Couch / Purple Rattan · 보류

![223 Couch PZ 왼쪽 MC 오른쪽](images/223_PZ_vs_MC.jpg)

PZ는 2×1 갈색 라탄 양팔걸이와 연분홍 좌석 2개/등받이를 가진 완성형 소파다. 기존 Macaw purple_couch 실제 Blockbench는 보라색 한쪽 조각으로 라탄·분홍 쿠션이 없다. 새 Decocraft couch_corner_purple BBMODEL 7 cubes를 Blockbench 5.2.2로 렌더하니 선명한 보라색의 두꺼운 코너/한 좌석 모듈일 뿐 라탄 골조와 연분홍 패브릭이 없고 2×1 완제품 결합도 미검증. 보류.

### 224 — Couch / Yellow Modern · 보류

![224 Couch PZ 왼쪽 MC 오른쪽](images/224_PZ_vs_MC.jpg)

PZ는 단색 황토 노란 1×2 현대식 직선 2인 소파다. 기존 Macaw yellow_couch 렌더는 단일 좌석/팔걸이 조각으로 2인 결합 미검증. 새 Decocraft bamboo_couch_left_yellow 원본 BBMODEL 34 cubes를 Blockbench 5.2.2로 렌더하니 녹색 대나무 개방형 프레임에 흰색·분홍 꽃무늬 쿠션과 분홍 등받이가 있는 단일 좌석 모듈이었다. PZ의 단색 노랑 두꺼운 프레임·낮은 직선 등받이와 색·재질·폭·형태가 다르다.

### 225 — Counter / Green Corner · 보류

![225 Counter PZ 왼쪽 MC 오른쪽](images/225_PZ_vs_MC.jpg)

PZ는 무광 올리브 단색 목재의 안쪽 직각 홈이 있는 L자 코너 카운터다. Decocraft diner_counter_corner_green 실제 BBMODEL 11 cubes를 Blockbench 5.2.2에서 재검증한 결과 채도 높은 녹색/흰색·은색의 수평 줄무늬와 검은 하부, 각진 다이너형 전면이었다. PZ의 단색 무장식 올리브 패널과 재질·색·코너 형상·인접 연결 구조가 다르다.

### 226 — Counter / Hardwood Floating · 보류

![226 Counter PZ 왼쪽 MC 오른쪽](images/226_PZ_vs_MC.jpg)

PZ는 짙은 갈색 벽걸이 2문 수납장, 전면 세로 판문 2개와 작은 손잡이, 다리 없는 상자형이다. 기존 mcwfurnitures:acacia_counter는 주황 상판/회색 돌 몸체의 높은 카운터로 오매칭이다. 새 Decocraft bottom_cabinet_2_oak 원본 BBMODEL 11 cubes를 Blockbench 5.2.2로 렌더하니 흰 상판·밝은 참나무 몸체에 검은 손잡이가 달린 가로 서랍 4개가 있는 바닥형 서랍장이었다. 문 개수·방향·높이·벽부착·재질이 모두 다르다.

### 227 — Shelves / White Wall · 보류

![227 Shelves PZ 왼쪽 MC 오른쪽](images/227_PZ_vs_MC.jpg)

PZ는 벽에 부착하는 얇고 긴 흰색/연회색 단일 선반판이다. Decocraft dish_rack_white 원본 BBMODEL 686 cubes를 Blockbench 5.2.2에서 렌더하니 갈색 나무 등판, 접시/컵과 걸린 수건·유리잔이 포함된 완성형 식기 거치대였다. PZ의 무장식 단일 판재와 두께·색상·부속품·벽면 배치가 다르므로 보류.

### 228 — Table / Black Low Modern · 보류

![228 Table PZ 왼쪽 MC 오른쪽](images/228_PZ_vs_MC.jpg)

PZ는 다리 없는 낮은 검정 직육면체의 통짜 커피 테이블/받침이다. Decocraft diner_table_black 원본 BBMODEL 12 cubes를 Blockbench 5.2.2에서 재렌더하니 검정 얇은 상판에 밝은 금속 테두리, 긴 중앙 금속 기둥과 넓은 바닥판이 있는 높은 식탁이었다. 높이·기둥·금속 비율·외곽 실루엣이 명백히 다르다.

### 229 — Beds / Twin · 조건부

![229 Beds PZ 왼쪽 MC 오른쪽](images/229_PZ_vs_MC.jpg)

PZ 2×1 조립은 빨간 목재 2층 침대, 흰색 상하 매트리스, 빨간 측면 사다리/난간이다. Decocraft bunk_bed_birch_black 원본 BBMODEL 66 cubes를 Blockbench 5.2.2에서 재렌더해 두 층, 4개 기둥, 측면 사다리와 난간이라는 기본 구조가 유사함을 확인했다. 그러나 밝은 자작나무 프레임과 검정/회색 침구, 촘촘한 세로 난간·사다리 위치는 PZ의 붉은 단순 수평 난간·흰 매트리스와 다르다. 구조적 대안으로만 조건부 보관하고 1:1 승인·설치 인증은 하지 않는다.

### 230 — Chair / Darkblue Modern · 보류

![230 Chair PZ 왼쪽 MC 오른쪽](images/230_PZ_vs_MC.jpg)

PZ는 짙은 남색 천 쿠션의 둥근 높은 등받이와 두툼한 좌판, 가느다란 검정 4다리 의자다. 기존 Macaw acacia_modern_chair Blockbench 캡처는 수직 기둥 하나만 보여 불완전했다. 새 Decocraft school_chair_blue 원본 BBMODEL 37 cubes를 Blockbench 5.2.2로 렌더하니 밝은 파란 평판 좌석과 분리된 직사각 등받이, 은색 금속 4다리의 교실 의자였다. 패딩·둥근 등받이·남색 천·검정 다리와 모두 다르다.

</details>

<details>
<summary><strong>231–240 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_231_240.md)

### 231 — Couch / Red Comfy · 보류

![231 Couch PZ 왼쪽 MC 오른쪽](images/231_PZ_vs_MC.jpg)

PZ는 오렌지색 두 좌석과 양끝 두꺼운 팔걸이·낮은 검정 다리의 2×1 완성 소파다. 기존 Macaw red_couch는 한쪽 소파 조각으로 완성 2인 결합 미확인. 이번 Decocraft couch_corner_red 원본 BBMODEL(7 cubes)을 공식 Blockbench 5.2.2로 렌더하니 짙은 빨강 단색 한 좌석 코너 모듈과 한쪽 팔걸이/높은 등받이가 나타났다. PZ의 밝은 오렌지 패브릭·두 좌석·양끝 팔걸이·검정 발과 색/조립이 달라 보류.

### 232 — Counter / Oak Floating · 보류

![232 Counter PZ 왼쪽 MC 오른쪽](images/232_PZ_vs_MC.jpg)

PZ는 벽에 매다는 중간 갈색 원목 2문 캐비닛(작은 손잡이 두 개)이다. 기존 Macaw dark_oak_counter는 문 없는 검정 갈색 통나무 블록. 새 Decocraft bathroom_counter_left_oak 원본 BBMODEL(13 cubes)은 흰색 두꺼운 상판, 밝은 참나무 측판, 열린 측면 수납칸과 흰 병/수건이 있는 바닥형 욕실 카운터로 확인됐다. 문·벽부착·색상·높이가 모두 다르다.

### 233 — Lamp / Fancy Green · 보류

![233 Lamp PZ 왼쪽 MC 오른쪽](images/233_PZ_vs_MC.jpg)

PZ는 금색 줄기에서 3개 곡선 가지와 녹색 갓·금색 장식이 내려오는 2×1 샹들리에다. 기존 decocraft:lamp_cable_base_black_green을 실제 Blockbench 5.2.2(6 cubes)로 재렌더하니 검정 긴 단일 수직 봉과 녹색 납작한 상단 캡만 있다. 3등 가지, 전등갓, 천장형 구조가 없어 보류.

### 234 — Sink / Fancy Hanging · 보류

![234 Sink PZ 왼쪽 MC 오른쪽](images/234_PZ_vs_MC.jpg)

PZ는 회색 스테인리스 벽판에 앞으로 돌출된 둥근 음수대와 금속 수도꼭지가 달린 1×1 벽걸이형 설비다. 기존 pfm:basic_sink Blockbench는 황색 평판 하나만 나오는 불완전 모델. 새 Decocraft sink_cabinet_white 원본 BBMODEL(10 cubes)은 흰색 바닥 수납장 상자와 문·경첩이며, 둥근 금속 물받이/수도꼭지/벽판이 없어 보류.

### 235 — Table / Long Oak · 보류

![235 Table PZ 왼쪽 MC 오른쪽](images/235_PZ_vs_MC.jpg)

PZ는 3×1 갈색 원목 상판, 얇은 검정 금속 4다리, 양끝 대각 보강대를 가진 긴 테이블이다. 기존 Macaw dark_oak_glass_table 캡처는 유리 평판 일부만 보이는 불완전 모델. 새 Decocraft kitchen_table_oak 원본 BBMODEL(29 cubes)은 두꺼운 흰 상판과 밝은 참나무 장식 기둥 4개를 가진 정사각/짧은 식탁이다. 상판 재질·3칸 길이·검정 금속 다리·보강대가 달라 보류.

### 236 — Counter / Pie Store · 보류

![236 Counter PZ 왼쪽 MC 오른쪽](images/236_PZ_vs_MC.jpg)

PZ는 연갈색 목재 상판과 흰색 세로 패널 몸체, 갈색 모서리 프레임을 가진 파이 가게용 1×1 카운터다. 기존 Macaw acacia_counter는 회색 석재 몸체/주황 상판. 새 Decocraft bottom_cabinet_1_white 원본 BBMODEL(13 cubes)은 흰 가로 프레임의 상단 서랍과 아래 수납문, 검정 손잡이 및 밝은 나무 상판을 가진 주방 하부장이다. 흰 몸체/목재 상판이라는 일부 유사성은 있지만 PZ의 무손잡이 세로 판재 카운터와 전면 구성이 다르므로 확정·조건부 승인하지 않는다.

### 237 — Bed / Hospital · 보류

![237 Bed PZ 왼쪽 MC 오른쪽](images/237_PZ_vs_MC.jpg)

PZ는 1×2 얇은 흰 매트리스, 짙은 녹색 금속 프레임, 머리·발끝에 얇은 튜브 난간을 가진 단층 병원 침대다. 기존 Decocraft 2층 나무 침대는 오매칭. 새 double_bed_oak_white 원본 BBMODEL(36 cubes)은 두 명이 눕는 넓은 밝은 참나무 프레임, 체크무늬 침구, 나무 헤드보드와 발판이 있는 일반 더블침대다. 병상 금속 난간·단인용 폭·녹색 프레임이 없어 보류.

### 238 — Bench / Long Wooden · 보류

![238 Bench PZ 왼쪽 MC 오른쪽](images/238_PZ_vs_MC.jpg)

PZ는 1×2 갈색 목재 판재 좌판과 양끝 사선 다리만 있는 등받이 없는 긴 벤치다. 기존 Handcrafted dark_oak_bench는 빨강 쿠션·등받이 있는 한쪽 좌석 모듈. 이번 Decocraft gym_bench 원본 BBMODEL(7 cubes)은 처음 Blockbench 캡처가 잘려 전체 형상을 판정할 수 없었지만, 넓은 카메라로 공식 Blockbench 5.2.2를 재실행하여 검정 패딩 상판과 검정 금속 사선 지지대가 있는 짧은 운동용 벤치임을 확인했다. PZ의 갈색 나무 긴 좌판·2칸 길이·목재 사선 다리와 재질/비율이 달라 보류.

### 239 — Chair / Rocking · 보류

![239 Chair PZ 왼쪽 MC 오른쪽](images/239_PZ_vs_MC.jpg)

PZ는 곡선 갈색 나무 러너, 말린 팔걸이, 높은 타원형 라탄 등받이와 라탄 좌판을 가진 1×1 흔들의자다. 기존 pfm:arm_chair_leather는 회색 판만 보이는 불완전 모델. 새 Decocraft beach_chair_gray 원본 BBMODEL(18 cubes)을 렌더하니 검정·흰색 줄무늬 천과 가는 밝은 나무 경사 프레임의 접이식 해변 의자다. 흔들목·라탄·곡선 팔걸이가 없어 보류.

### 240 — Couch / Victorian C5 · 보류

![240 Couch PZ 왼쪽 MC 오른쪽](images/240_PZ_vs_MC.jpg)

PZ는 1×2 갈색 가죽 빅토리아풍 비대칭 셰즈로, 높은 한쪽 등받이/팔걸이에 둥근 단추형 퀼팅이 가득하다. 기존 Macaw black_couch는 검정 한 좌석 소파 조각이다. 새 Decocraft couch_corner_leather_brown 원본 BBMODEL(7 cubes)은 갈색 단색 평면 코너 모듈 1석으로 확인됐다. 단추형 퀼팅·긴 비대칭 몸체·1×2 전체 조립이 없어 보류.

</details>

<details>
<summary><strong>241–250 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_241_250.md)

### 241 — Fancy Dark Table / 기본 · 보류

![241 Fancy Dark Table PZ 왼쪽 MC 오른쪽](images/241_PZ_vs_MC.jpg)

table geometry and wood color absent

### 242 — Industrial / Bake-O-Matic · 보류

![242 Industrial PZ 왼쪽 MC 오른쪽](images/242_PZ_vs_MC.jpg)

different appliance, shape, material, footprint and height

### 243 — Mirror / Middle · 보류

![243 Mirror PZ 왼쪽 MC 오른쪽](images/243_PZ_vs_MC.jpg)

outline and frame strongly differ; downgrade prior conditional match

### 244 — Radio / Premium Technologies Ham · 보류

![244 Radio PZ 왼쪽 MC 오른쪽](images/244_PZ_vs_MC.jpg)

missing actual MC asset; no visual comparison possible

### 245 — Sink / Beige · 보류

![245 Sink PZ 왼쪽 MC 오른쪽](images/245_PZ_vs_MC.jpg)

partial import is not complete candidate evidence; no faithful sink shape

### 246 — Table / Long Dark Oak · 보류

![246 Table PZ 왼쪽 MC 오른쪽](images/246_PZ_vs_MC.jpg)

material and 1x3 footprint mismatch; partial source render

### 247 — Chair / Salon · 보류

![247 Chair PZ 왼쪽 MC 오른쪽](images/247_PZ_vs_MC.jpg)

no chair seat, armrests or pedestal; partial model evidence

### 248 — Desk / Office 2 · 보류

![248 Desk PZ 왼쪽 MC 오른쪽](images/248_PZ_vs_MC.jpg)

missing 3x1 desk assembly, tabletop and cabinet; partial side segment

### 249 — Shelves / Fancy Wooden Shop · 보류

![249 Shelves PZ 왼쪽 MC 오른쪽](images/249_PZ_vs_MC.jpg)

open display geometry absent; major material/color mismatch

### 250 — Chair / Victorian 5 · 보류

![250 Chair PZ 왼쪽 MC 오른쪽](images/250_PZ_vs_MC.jpg)

missing upholstery, arms, seat and wood trim; partial model evidence

</details>

<details>
<summary><strong>251–260 (10종, 조건부 2 / 보류 8)</strong></summary>

[이 묶음만 보기](batches/BATCH_251_260.md)

### 251 — Counter / Birchwood Floating Corner · 보류

![251 Counter PZ 왼쪽 MC 오른쪽](images/251_PZ_vs_MC.jpg)

PZ 원본은 밝은 자작나무색의 높은 벽걸이 ㄱ자 코너 수납장(IsHigh, WallObject)인데 Decocraft 후보는 검은색/흰 줄무늬의 바닥형 식당 카운터 코너다. 코너 윤곽만 일부 유사하고 재질·색상·설치 높이·수납 구조가 다르다.

### 252 — Drawers / Lit Mirror And · 보류

![252 Drawers PZ 왼쪽 MC 오른쪽](images/252_PZ_vs_MC.jpg)

PZ는 3단 서랍과 조명이 달린 거울이 결합된 화장대다. 후보 Blockbench 비교는 녹색 평면 하나만 나타나는 불완전 JSON 렌더로 서랍·거울·조명이 전혀 확인되지 않는다. 부분 렌더를 완성 모델로 승인할 수 없다.

### 253 — Fridge / Blue · 조건부

![253 Fridge PZ 왼쪽 MC 오른쪽](images/253_PZ_vs_MC.jpg)

Decocraft의 청색 소형 2도어 냉장고는 전체 외곽, 높이, 냉장고 문 2개 구조가 유사하다. 그러나 PZ는 청록색이며 상하 문 비율·문턱 위치·손잡이 형태가 다르고 후보는 더 탁한 회청색이다. 조건부 외형 후보만 유지한다.

### 254 — Fridge / Red · 조건부

![254 Fridge PZ 왼쪽 MC 오른쪽](images/254_PZ_vs_MC.jpg)

Decocraft의 적색 소형 2도어 냉장고는 빨간 외장·상단 작은 문/하단 큰 문 구조가 유사하다. 하지만 PZ는 더 둥글고 은색 가로 띠가 두드러지며 후보는 손잡이가 전면으로 튀어나오고 문 비율·테두리가 다르다. 조건부 외형 후보만 유지한다.

### 255 — Low Table / Long Fancy · 보류

![255 Low Table PZ 왼쪽 MC 오른쪽](images/255_PZ_vs_MC.jpg)

PZ는 2타일 길이의 진갈색 곡선 다리 장식 테이블이다. Macaw's 후보는 1블록 크기의 회갈색 얇은 정사각 슬래브만 보여 다리·곡선 장식·2×1 길이·목재 색상이 불일치한다.

### 256 — Washing Machine / White · 보류

![256 Washing Machine PZ 왼쪽 MC 오른쪽](images/256_PZ_vs_MC.jpg)

PZ는 위로 여는 탑로더 세탁기이고 Decocraft 후보는 전면 원형 투입구와 앞쪽 조작판이 있는 프런트로더다. 핵심 투입 방향·뚜껑·조작 패널이 달라 대체 불가.

### 257 — Counter / Oak Bar · 보류

![257 Counter PZ 왼쪽 MC 오른쪽](images/257_PZ_vs_MC.jpg)

PZ는 밝은 목재 상판과 어두운 세로 판넬, 바닥 테두리가 분리되어 있다. Macaw's dark oak 후보는 거의 전체가 짙은 통나무 질감의 단순 큐브로 밝은 상판·수직 패널·하부 몰딩이 없다. 이름과 재질 계열만 유사하다.

### 258 — Counter / Zippee · 보류

![258 Counter PZ 왼쪽 MC 오른쪽](images/258_PZ_vs_MC.jpg)

PZ는 선명한 빨강 상판과 흰색 하부가 특징인 카운터다. 후보는 오렌지/갈색 상판 아래 회흑색 석재·목재 질감의 큐브이며 흰 하부가 없다. 색상·재질·모서리 형상이 불일치한다.

### 259 — Shelves / Small Rental · 보류

![259 Shelves PZ 왼쪽 MC 오른쪽](images/259_PZ_vs_MC.jpg)

PZ는 2칸 길이의 밝은 개방형 3단 선반이다. Handcrafted 후보는 붉은 아카시아색 1블록 높이 큐브의 검은 전면 홈 2개로 보이며, 양끝 기둥/3단 긴 선반/2타일 조립이 확인되지 않는다. 원본 JSON의 누락 부모 참조도 재확인 필요.

### 260 — Table / Spiffos Type A · 보류

![260 Table PZ 왼쪽 MC 오른쪽](images/260_PZ_vs_MC.jpg)

PZ는 2타일 길이의 직사각 식당 테이블로 주황 테두리·중앙 금속 받침이 있다. 후보의 Blockbench 화면에는 얇은 밝은 목재 평면만 나타나며 다리/받침·주황 테두리·2타일 연결이 확인되지 않는다. 부분 JSON 렌더는 완성형 증거가 아니다.

</details>

<details>
<summary><strong>261–270 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_261_270.md)

### 261 — Beds / Bunk · 보류

![261 Beds PZ 왼쪽 MC 오른쪽](images/261_PZ_vs_MC.jpg)

PZ는 검은색/갈색 금속 프레임과 흰 매트리스의 단순 2단 침대이고 Decocraft 후보는 밝은 자작나무 목재 프레임, 계단형 사다리, 검정 무늬 침구를 가진 침대다. 2단 구성은 유사하지만 프레임 재질·색·사다리·난간·침구가 다르므로 조건부 승인도 보류한다.

### 262 — Chair / Victorian 3 · 보류

![262 Chair PZ 왼쪽 MC 오른쪽](images/262_PZ_vs_MC.jpg)

PZ는 줄무늬 빅토리아풍 천 안락의자다. 현재 Paladin 후보의 Blockbench JSON 비교 화면은 회색 판 형태만 보여 등받이·팔걸이·다리·줄무늬 원단이 검증되지 않는다. 부분 렌더를 완성 가구로 판정할 수 없다.

### 263 — Chair / Victorian 4 · 보류

![263 Chair PZ 왼쪽 MC 오른쪽](images/263_PZ_vs_MC.jpg)

PZ는 검은색 가죽 버튼 퀼팅의 빅토리아 안락의자다. 후보 화면은 262번과 동일한 회색 판형 부분 JSON 렌더로 가죽·버튼·팔걸이·좌석 형상을 전혀 확인할 수 없다.

### 264 — Counter / Dark Bar · 보류

![264 Counter PZ 왼쪽 MC 오른쪽](images/264_PZ_vs_MC.jpg)

PZ는 거의 검정에 가까운 짙은 목재 카운터다. Macaw's 후보는 주황색 아카시아 상판과 회색/갈색 통나무 껍질 질감 몸체로 색상·패널 재질·하단 몰딩이 다르다.

### 265 — Counter / White Display · 보류

![265 Counter PZ 왼쪽 MC 오른쪽](images/265_PZ_vs_MC.jpg)

PZ는 세 칸 길이의 유리 식품 진열 냉장 쇼케이스인데 Decocraft 후보는 목재 상판을 가진 1칸 흰색 욕실 카운터/수납장이다. 길이·투명 진열창·냉장 기능·재질이 불일치한다.

### 266 — Table / Spiffos Type B · 보류

![266 Table PZ 왼쪽 MC 오른쪽](images/266_PZ_vs_MC.jpg)

PZ 조립 미리보기는 두 개의 주황색 테이블 상판 중 하나의 지지대가 보이지 않아 조립 상태도 추가 검증이 필요하다. 후보 Blockbench JSON은 밝은 단일 평면만 나타나는 부분 렌더로 두 상판·중앙 금속 받침·2×1 연결을 입증하지 못한다.

### 267 — Bed / Light Wood · 보류

![267 Bed PZ 왼쪽 MC 오른쪽](images/267_PZ_vs_MC.jpg)

PZ 원본 미리보기는 높은 세로 난간으로 둘러싸인 단층 유아 침대(크립) 형태다. Decocraft 후보는 밝은 목재이지만 2층 침대와 사다리가 있어 높이·층수·구조가 다르다. Bed / Light Wood 분류와 실제 크립 형태도 원본 타일 ID로 확인해야 한다.

### 268 — Counter / Green Floating · 보류

![268 Counter PZ 왼쪽 MC 오른쪽](images/268_PZ_vs_MC.jpg)

PZ는 평평한 상판과 두 문이 있는 올리브색 벽걸이 수납장이다. Decocraft 후보는 녹색·흰색 수평 줄무늬와 검정 하부를 가진 바닥형 식당 카운터 코너로 벽걸이·문·손잡이·색상/형태가 다르다.

### 269 — Drum / Kick · 보류

![269 Drum PZ 왼쪽 MC 오른쪽](images/269_PZ_vs_MC.jpg)

PZ는 빨간 베이스 드럼/탐 부분 세트이고 Decocraft 후보는 검정/흰색 전체 드럼 키트로 심벌·스네어·의자 등 불필요한 부품이 많고 색상·점유 면적이 다르다.

### 270 — Drum / Snare · 보류

![270 Drum PZ 왼쪽 MC 오른쪽](images/270_PZ_vs_MC.jpg)

PZ는 붉은 스네어와 심벌이 분리 배치된 작은 1×1 악기다. 후보는 검정 대형 풀 드럼 세트라 악기 수·색·스탠드·전체 크기가 다르다.

</details>

<details>
<summary><strong>271–280 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_271_280.md)

### 271 — Drum / Tom · 보류

![271 Drum PZ 왼쪽 MC 오른쪽](images/271_PZ_vs_MC.jpg)

단일 빨간 탐+심벌과 검정 전체 드럼 세트의 색상·개수·크기 불일치

### 272 — Machine / Kaboom Arcade · 보류

![272 Machine PZ 왼쪽 MC 오른쪽](images/272_PZ_vs_MC.jpg)

아케이드 실루엣만 비슷하고 게임 화면·색상·상단 형태가 다름

### 273 — Radio / Premium Technologies · 보류

![273 Radio PZ 왼쪽 MC 오른쪽](images/273_PZ_vs_MC.jpg)

원본 모드 자산이 없어 시각 대조 자체가 불가

### 274 — Shelves / Dark Wall · 보류

![274 Shelves PZ 왼쪽 MC 오른쪽](images/274_PZ_vs_MC.jpg)

부유 판자와 두꺼운 수납형 가구의 구조·색·두께 불일치

### 275 — Stool / Drum · 보류

![275 Stool PZ 왼쪽 MC 오른쪽](images/275_PZ_vs_MC.jpg)

재질·좌판 모양 불일치, 부분 렌더이므로 완전 모델 판정 불가

### 276 — Table / Long Light · 보류

![276 Table PZ 왼쪽 MC 오른쪽](images/276_PZ_vs_MC.jpg)

목재 상판·길이·다리 구조 미재현, 부분 렌더

### 277 — Chair / Patient · 보류

![277 Chair PZ 왼쪽 MC 오른쪽](images/277_PZ_vs_MC.jpg)

의료 진찰대와 가죽 안락의자 후보가 다르고 2×1 점유 미충족

### 278 — Counter / Middle · 보류

![278 Counter PZ 왼쪽 MC 오른쪽](images/278_PZ_vs_MC.jpg)

유리 덮개·금속 용기·내부 공간이 전혀 없음

### 279 — Counter / Mobile Tool · 보류

![279 Counter PZ 왼쪽 MC 오른쪽](images/279_PZ_vs_MC.jpg)

이동식 바퀴·트레이·금속 지지대 모두 누락

### 280 — Counter / Oak Employee Bank · 보류

![280 Counter PZ 왼쪽 MC 오른쪽](images/280_PZ_vs_MC.jpg)

2×1 점유·투톤 색상·위쪽 칸막이 두 개 전부 불일치

</details>

<details>
<summary><strong>281–290 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_281_290.md)

### 281 — Counter / Pizzawhirled · 보류

![281 Counter PZ 왼쪽 MC 오른쪽](images/281_PZ_vs_MC.jpg)



### 282 — Counter / Quality Crafted · 보류

![282 Counter PZ 왼쪽 MC 오른쪽](images/282_PZ_vs_MC.jpg)



### 283 — Counter / Rounded Glass Display · 보류

![283 Counter PZ 왼쪽 MC 오른쪽](images/283_PZ_vs_MC.jpg)



### 284 — Counter / Theater · 보류

![284 Counter PZ 왼쪽 MC 오른쪽](images/284_PZ_vs_MC.jpg)



### 285 — Locker / Military · 보류

![285 Locker PZ 왼쪽 MC 오른쪽](images/285_PZ_vs_MC.jpg)



### 286 — Table / Large Bleached · 보류

![286 Table PZ 왼쪽 MC 오른쪽](images/286_PZ_vs_MC.jpg)



### 287 — Table / Pizza Dinner · 보류

![287 Table PZ 왼쪽 MC 오른쪽](images/287_PZ_vs_MC.jpg)



### 288 — Wardrobe / Open · 보류

![288 Wardrobe PZ 왼쪽 MC 오른쪽](images/288_PZ_vs_MC.jpg)



### 289 — Amplifier / Guitar · 보류

![289 Amplifier PZ 왼쪽 MC 오른쪽](images/289_PZ_vs_MC.jpg)



### 290 — Dishwasher / Brown · 조건부

![290 Dishwasher PZ 왼쪽 MC 오른쪽](images/290_PZ_vs_MC.jpg)



</details>

<details>
<summary><strong>291–300 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_291_300.md)

### 291 — Ottoman / Orange · 보류

![291 Ottoman PZ 왼쪽 MC 오른쪽](images/291_PZ_vs_MC.jpg)

PZ는 무늬 없는 주황색 작은 발받침이지만 MC 원본 cottage_footstool은 흰 바탕에 꽃무늬가 반복되는 두꺼운 발받침이다. 용도만 같고 색상·무늬·비례가 다르다.

### 292 — Oven / Antique · 보류

![292 Oven PZ 왼쪽 MC 오른쪽](images/292_PZ_vs_MC.jpg)

PZ는 검정 철제 장작난로와 가는 금속 연통이지만 MC pizza_oven은 붉은 벽돌 바닥과 넓은 돔 화실·굵은 벽돌 굴뚝의 야외 피자 화덕이다. 재질·실루엣·기능이 다르다.

### 293 — Shelves / Big Wall Corner · 보류

![293 Shelves PZ 왼쪽 MC 오른쪽](images/293_PZ_vs_MC.jpg)

PZ는 직각으로 꺾인 개방형 3단 코너 선반인데 MC acacia_shelf는 단일 목재 상자형 덩어리처럼 보이고 열린 L자 코너와 세 선반 층이 보이지 않는다.

### 294 — Speaker Cabinet / Guitar · 보류

![294 Speaker Cabinet PZ 왼쪽 MC 오른쪽](images/294_PZ_vs_MC.jpg)

PZ는 검정 세로형 기타 스피커 캐비닛이지만 기존 모드 조사에서 대응 MC 원본 모델이 확인되지 않았다. 오른쪽은 미검증 안내판으로 실제 MC 모델 렌더가 아니다.

### 295 — Speaker Cabinet / Wood · 보류

![295 Speaker Cabinet PZ 왼쪽 MC 오른쪽](images/295_PZ_vs_MC.jpg)

PZ는 두 원형 드라이버가 노출된 목재 스피커인데 기존 MC 원본 후보가 없고 오른쪽은 안내판이다. 실제 모델 비교가 없어 승인 불가다.

### 296 — Terminal / CeroSec · 보류

![296 Terminal PZ 왼쪽 MC 오른쪽](images/296_PZ_vs_MC.jpg)

PZ는 버튼과 디스플레이가 다수 있는 경사형 보안 콘솔이지만 MC computer 비교는 베이지색 단순 상자형 부분 JSON 렌더다. 화면·키패드·경사 제어판이 보이지 않고 완성 모델도 검증되지 않았다.

### 297 — Chair / Exceptionally crafted · 보류

![297 Chair PZ 왼쪽 MC 오른쪽](images/297_PZ_vs_MC.jpg)

PZ는 팔걸이 없는 목재 의자지만 MC arm_chair_leather는 가죽 안락의자 종류이며 기존 Blockbench JSON 화면도 회색 판형 부분 렌더다. 종류·재질·등받이 구조가 불일치한다.

### 298 — Counter / Corner A · 보류

![298 Counter PZ 왼쪽 MC 오른쪽](images/298_PZ_vs_MC.jpg)

PZ는 금속/유리 코너 진열대와 투명 가림막이지만 MC는 검정 몸체와 회색 줄무늬의 불투명 카운터다. 유리·진열홈·상부 프레임이 없다.

### 299 — Counter / Corner B · 보류

![299 Counter PZ 왼쪽 MC 오른쪽](images/299_PZ_vs_MC.jpg)

PZ는 298번과 프레임 방향이 반대인 유리 진열 코너인데 MC는 298과 동일한 불투명 검정 카운터를 재사용한다. 유리와 상단 구조도 없고 회전별 차이도 입증되지 않았다.

### 300 — Counter / Fossoil · 보류

![300 Counter PZ 왼쪽 MC 오른쪽](images/300_PZ_vs_MC.jpg)

PZ는 크림색 몸체와 파란 상판의 주유소 카운터인데 MC acacia_counter는 주황색 아카시아 상판과 회색/갈색 나무껍질 질감 몸체다. 색상·재질·패널이 불일치한다.

</details>

<details>
<summary><strong>301–310 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_301_310.md)

### 301 — Counter / Glass Corner Display · 보류

![301 Counter PZ 왼쪽 MC 오른쪽](images/301_PZ_vs_MC.jpg)

MC는 검정 본체에 은색 수평 줄무늬만 있는 불투명 다이너 카운터로 투명 유리와 열린 진열 공간이 없음

### 302 — Counter / Glass Theater · 보류

![302 Counter PZ 왼쪽 MC 오른쪽](images/302_PZ_vs_MC.jpg)

MC 아카시아 카운터는 회갈색 불투명 몸체와 주황색 상판으로 투명 유리·전면 개구부가 없음

### 303 — Counter / Pie Store Corner · 보류

![303 Counter PZ 왼쪽 MC 오른쪽](images/303_PZ_vs_MC.jpg)

MC 검정 금속 다이너 코너 카운터는 재질과 검정/은색 띠가 다르고 나무 상판과 크림색 패널이 없음

### 304 — Counter / Seahorse Coffee · 보류

![304 Counter PZ 왼쪽 MC 오른쪽](images/304_PZ_vs_MC.jpg)

MC 아카시아 카운터는 밝은 주황 상판과 회색/갈색 거친 나무무늬 몸체로 색상·표면 질감이 다름

### 305 — Shelves / Wooden Shop · 보류

![305 Shelves PZ 왼쪽 MC 오른쪽](images/305_PZ_vs_MC.jpg)

MC 짙은 갈색 상자형 렌더로 전면 2개 선반판과 개방된 구조가 확인되지 않음

### 306 — Shelves / Zippee Low Wall · 보류

![306 Shelves PZ 왼쪽 MC 오른쪽](images/306_PZ_vs_MC.jpg)

MC는 주황/갈색 나무 질감의 단단한 상자형 선반 렌더로 흰색·빨간 테두리 및 얇은 판 구조가 없음

### 307 — Table / Exceptional Large · 보류

![307 Table PZ 왼쪽 MC 오른쪽](images/307_PZ_vs_MC.jpg)

MC 후보는 접시·컵·포크·나이프 테이블 세팅 소품뿐이며 탁자 본체·다리·2×1 점유가 없음

### 308 — Bowling Machine / 기본 · 보류

![308 Bowling Machine PZ 왼쪽 MC 오른쪽](images/308_PZ_vs_MC.jpg)

MC 비교 화면에 검증된 실제 모드 모델이 없어 3D 비교 자체 불가

### 309 — Bowling Rack / 기본 · 보류

![309 Bowling Rack PZ 왼쪽 MC 오른쪽](images/309_PZ_vs_MC.jpg)

MC는 목재 선반·옷걸이·다색 의류가 달린 큰 의류 진열대라 사물 용도와 형상이 다름

### 310 — Chair / Rocking 2 · 보류

![310 Chair PZ 왼쪽 MC 오른쪽](images/310_PZ_vs_MC.jpg)

MC 후보는 회색 평판만 보이는 부분 JSON 렌더로 의자 좌석·팔걸이·곡선 흔들다리 전혀 확인 불가

</details>

<details>
<summary><strong>311–320 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_311_320.md)

### 311 — Chair / Victorian 6 · 보류

![311 Chair PZ 왼쪽 MC 오른쪽](images/311_PZ_vs_MC.jpg)

PZ는 빅토리아식 베이지 버튼터프팅 안락의자. 기존 Minecraft 이미지는 회색 평판/벽면 형태만 나타나 좌석·팔걸이·다리·쿠션이 확인되지 않는다. 원본 JSON 부분 렌더이므로 실제 가구 외형 비교 불가능.

### 312 — Couch / Victorian C4 · 보류

![312 Couch PZ 왼쪽 MC 오른쪽](images/312_PZ_vs_MC.jpg)

PZ는 2×1 검정 가죽 체스터필드 소파로 둥근 팔걸이와 버튼 장식이 뚜렷하다. Minecraft 후보는 각진 검정 단일 소파 블록/부분 모듈이며 원본의 2좌석 길이·팔걸이·터프팅을 재현하지 않는다.

### 313 — Counter / Darkwood Floating Corner · 보류

![313 Counter PZ 왼쪽 MC 오른쪽](images/313_PZ_vs_MC.jpg)

PZ는 나무 상판이 꺾인 짙은 갈색 벽부착 코너 수납장이다. 후보는 검은색 본체와 은색 가로 띠의 바닥형 다이너 카운터로 재질·설치 높이·색상·구조가 모두 다르다.

### 314 — Dishwasher / Metal · 조건부

![314 Dishwasher PZ 왼쪽 MC 오른쪽](images/314_PZ_vs_MC.jpg)

PZ와 Minecraft 후보 모두 회색 직육면체 식기세척기 형태여서 구조적 유사성이 있다. 그러나 PZ는 넓은 검정 전면 사각 패널과 하부 통풍구, 후보는 회색 전면도어와 상단 작은 조작부/손잡이여서 전면 구성과 비율이 다르다. 인게임 기능·충돌 미검증.

### 315 — Machine / Dr. Oids Arcade · 보류

![315 Machine PZ 왼쪽 MC 오른쪽](images/315_PZ_vs_MC.jpg)

양쪽 모두 직립형 아케이드 캐비닛이지만 PZ의 노란 얼굴·분홍 캐릭터/문양과 후보의 초록 스페이스 인베이더 픽셀 그래픽은 완전히 다르다. 상단 장식과 조작부, 측면 디자인도 불일치한다.

### 316 — Machine / PAWS Pinball · 보류

![316 Machine PZ 왼쪽 MC 오른쪽](images/316_PZ_vs_MC.jpg)

PZ 원본은 PAWS 로고가 있는 2×1 핀볼 기계로 경사판·백박스·다리가 모두 보인다. 기존 비교 이미지에는 Minecraft 모델이 없다고 표시되어 실제 원본 모델 대조 자체가 불가능하다.

### 317 — Mirror / Corner A · 보류

![317 Mirror PZ 왼쪽 MC 오른쪽](images/317_PZ_vs_MC.jpg)

PZ는 얇은 회색 테두리의 높은 직사각 평면 거울이다. 후보는 두꺼운 검은 다각형 아치 프레임으로 상단 모양·프레임 두께·재질이 다르다. 벽부착/반사 기능도 미검증.

### 318 — Mirror / Corner B · 보류

![318 Mirror PZ 왼쪽 MC 오른쪽](images/318_PZ_vs_MC.jpg)

PZ 코너 B는 얇은 테두리와 푸른 유리의 직사각 거울이며 A와 배치 방향만 다르다. Minecraft 후보는 317번과 동일한 두꺼운 검은 아치 거울이라 외곽 형태와 프레임 색이 맞지 않고 A/B 방향 대응도 검증되지 않았다.

### 319 — Projector / Cinema · 보류

![319 Projector PZ 왼쪽 MC 오른쪽](images/319_PZ_vs_MC.jpg)

PZ는 좌우의 원형 필름 릴이 뚜렷한 구식 영화 영사기다. Minecraft 후보 이미지가 'MOD FURNITURE NOT VERIFIED'로 비어 있어 비교할 실제 3D 모델이 없다.

### 320 — Table / Large Light · 보류

![320 Table PZ 왼쪽 MC 오른쪽](images/320_PZ_vs_MC.jpg)

PZ는 밝은 원목 2×2 식탁 전체와 네 다리다. Minecraft 후보는 접시·컵·수저 세팅 소품으로 식탁 본체/다리가 전혀 없다. 2×2 멀티타일 구조도 대응하지 못한다.

</details>

<details>
<summary><strong>321–330 (10종, 조건부 0 / 보류 10)</strong></summary>

[이 묶음만 보기](batches/BATCH_321_330.md)

### 321 — Table / Long White · 보류

![321 Table PZ 왼쪽 MC 오른쪽](images/321_PZ_vs_MC.jpg)

PZ는 3×1 길이의 연한 목재 상판과 긴 가로 지지대가 있는 테이블이다. MC kitchen_table_white는 정사각형 1블록 갈색 상판·밝은 다리로 렌더되어 길이·색·지지대·멀티타일 점유가 불일치한다.

### 322 — Walkie Talkie / Toys-R-Mine · 보류

![322 Walkie Talkie PZ 왼쪽 MC 오른쪽](images/322_PZ_vs_MC.jpg)

PZ는 작은 검정 무전기지만 검증된 Minecraft 모드 원본 모델이 없다. 우측은 안내 카드로 실제 3D 렌더가 아니다. 통신 기능도 검증되지 않았다.

### 323 — Cabinet / Wide Medical · 보류

![323 Cabinet PZ 왼쪽 MC 오른쪽](images/323_PZ_vs_MC.jpg)

PZ는 금속 의료 수납장에 경사진 상단과 밝은 패널·하단 양문이 있지만 MC 후보는 어두운 아카시아 통나무 질감과 붉은 문처럼 보이는 부분 JSON 렌더다. 재질·색·형상이 다르고 완성 모델 증거도 부족하다.

### 324 — Counter / Crafted · 보류

![324 Counter PZ 왼쪽 MC 오른쪽](images/324_PZ_vs_MC.jpg)

PZ는 짙은 갈색 판재를 수직으로 조립한 카운터인데 MC acacia_counter는 주황 상판과 회흑색 나무껍질 질감의 단순 상자다. 판재 배열·재질·색상이 다르다.

### 325 — Counter / Dark Bar Corner · 보류

![325 Counter PZ 왼쪽 MC 오른쪽](images/325_PZ_vs_MC.jpg)

둘 다 코너형이지만 PZ는 짙은 갈색 목재이고 MC는 검정 몸체에 굵은 은회색 가로 줄무늬가 반복되는 식당 카운터다. 상판·전면 질감이 다르다.

### 326 — Counter / Motel Corner · 보류

![326 Counter PZ 왼쪽 MC 오른쪽](images/326_PZ_vs_MC.jpg)

PZ는 밝은 아이보리색 모텔 코너 카운터인데 MC 후보는 검정 몸체와 은회색 띠의 식당 카운터다. 코너 실루엣 외 색상·패널·재질이 다르다.

### 327 — Counter / Zippee Corner · 보류

![327 Counter PZ 왼쪽 MC 오른쪽](images/327_PZ_vs_MC.jpg)

PZ는 빨간 상판과 흰색 하부의 Zippee 코너인데 MC 후보는 검정·은색 줄무늬 카운터다. 상판·하부 색상과 패널 질감이 다르다.

### 328 — Counter / Zippee Display · 보류

![328 Counter PZ 왼쪽 MC 오른쪽](images/328_PZ_vs_MC.jpg)

PZ는 빨간 상판 아래 열린 진열 선반이 있지만 MC acacia_counter는 주황 상판과 어두운 나무껍질 질감의 불투명 상자다. 열린 진열공간·색상·재질이 다르다.

### 329 — Shelves / Clothing Shop · 보류

![329 Shelves PZ 왼쪽 MC 오른쪽](images/329_PZ_vs_MC.jpg)

PZ는 검정 의류 걸이 봉과 갈색 받침이 분리된 벽걸이 구조인데 MC acacia_shelf는 두꺼운 갈색 목재 덩어리 형태의 선반이다. 금속 봉·벽 고정 구조·빈 공간이 다르다.

### 330 — Shelves / Crafted Wooden · 보류

![330 Shelves PZ 왼쪽 MC 오른쪽](images/330_PZ_vs_MC.jpg)

PZ는 전면이 크게 열린 3단 원목 선반인데 MC dark_oak_shelf JSON 렌더는 어두운 목재의 닫힌 상자처럼 보여 개방된 3단 구조가 확인되지 않는다. 승인할 수 없다.

</details>

<details>
<summary><strong>331–340 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_331_340.md)

### 331 — Shelves / Fossoil Low · 보류

![331 Shelves PZ 왼쪽 MC 오른쪽](images/331_PZ_vs_MC.jpg)

Handcrafted 아카시아 후보는 주황빛 닫힌 상자처럼 보이고 어두운 전면 구멍만 있으며 파란 상판·밝은 2단 오픈 선반 구조가 없음

### 332 — Shelves / Generic Shop Low · 보류

![332 Shelves PZ 왼쪽 MC 오른쪽](images/332_PZ_vs_MC.jpg)

Handcrafted 아카시아 후보는 어두운 주황 갈색 상자형 렌더이며 열린 밝은 선반판 두 개가 나타나지 않음

### 333 — Shelves / Greene's Grocery · 보류

![333 Shelves PZ 왼쪽 MC 오른쪽](images/333_PZ_vs_MC.jpg)

MC 1×1 상자형 아카시아 선반은 4블록 길이와 3단 선반, 측면 걸이 및 개방형 구조를 재현하지 못함

### 334 — Stool / Organs · 보류

![334 Stool PZ 왼쪽 MC 오른쪽](images/334_PZ_vs_MC.jpg)

Macaw 아카시아 스툴은 얇은 평판 일부만 렌더되어 네 다리·측면 프레임이 전혀 검증되지 않으며 색도 밝은 주황 계열

### 335 — Table / Morgue · 보류

![335 Table PZ 왼쪽 MC 오른쪽](images/335_PZ_vs_MC.jpg)

MC 아카시아 유리 탁자 후보는 노란색 평판 부분만 보이며 금속 트레이·수도꼭지·중앙 기둥 및 1×2 길이가 없음

### 336 — Bed / Oak · 조건부

![336 Bed PZ 왼쪽 MC 오른쪽](images/336_PZ_vs_MC.jpg)

Decocraft crib_oak는 밝은 목재 난간·다리의 전체적인 사물 종류와 형태가 상당히 비슷하지만 상부 모빌과 장식물이 추가되고 높이·크기 및 설치 점유가 불확실

### 337 — Couch / Victorian C3 · 보류

![337 Couch PZ 왼쪽 MC 오른쪽](images/337_PZ_vs_MC.jpg)

MC 검정 소파는 단색 검정 직각 쿠션과 블록형 형태로 줄무늬·곡선 팔걸이·목재 장식 다리가 전혀 다름

### 338 — Couch / Victorian C6 · 보류

![338 Couch PZ 왼쪽 MC 오른쪽](images/338_PZ_vs_MC.jpg)

MC 검정 직선형 소파는 색상과 등받이 곡률, 크림색 버튼 장식, 다리 구조가 전부 불일치

### 339 — Counter / Oakwood Floating Corner · 보류

![339 Counter PZ 왼쪽 MC 오른쪽](images/339_PZ_vs_MC.jpg)

Decocraft 검정·은색 줄무늬 다이너 코너 카운터는 재질·색·전면 패널이 다르고 바닥형 모델로 벽면 부착 상부 가구를 대체할 수 없음

### 340 — Counter / Steel Floating Corner · 보류

![340 Counter PZ 왼쪽 MC 오른쪽](images/340_PZ_vs_MC.jpg)

Decocraft 검정·은색 줄무늬 다이너 코너 카운터는 검정 바닥형 가구로 회색 벽걸이 코너 금속장의 색상·재질·설치 높이가 다름

</details>

<details>
<summary><strong>341–350 (10종, 조건부 1 / 보류 9)</strong></summary>

[이 묶음만 보기](batches/BATCH_341_350.md)

### 341 — Counter / White Floating Corner · 보류

![341 Counter PZ 왼쪽 MC 오른쪽](images/341_PZ_vs_MC.jpg)

PZ는 밝은 아이보리색의 ㄱ자 형태로 한쪽에 파인 홈이 있으며 금속 줄무늬가 없다. Decocraft 후보는 청록색 금속 띠가 둘러진 검정 바닥 받침형 카운터로 색상, 표면, 설치 높이와 구조가 모두 다르다.

### 342 — CustomName / Premium Technologies Ham · 보류

![342 CustomName PZ 왼쪽 MC 오른쪽](images/342_PZ_vs_MC.jpg)

PZ Premium Technologies Ham은 작은 회색 직육면체 본체와 검정 유선 핸드마이크가 연결된 탁상형 무전기다. Minecraft 측은 원본 검증 모델이 없어 형상·재질·기능 비교 자체가 불가능하다.

### 343 — CustomName / US ARMY COMM. Ham · 보류

![343 CustomName PZ 왼쪽 MC 오른쪽](images/343_PZ_vs_MC.jpg)

PZ US ARMY COMM. Ham은 짙은 올리브색 군용 통신기 본체와 검정 유선 마이크를 갖는다. 원본 검증된 Minecraft 모델이 없으며 342번 회색 민간용과 색상·외형이 다르다.

### 344 — CustomName / ValuTech · 보류

![344 CustomName PZ 왼쪽 MC 오른쪽](images/344_PZ_vs_MC.jpg)

PZ ValuTech는 작은 검정/회색 휴대용 라디오이며 상부 안테나와 전면 다이얼/표시부가 있다. Minecraft 후보 모델이 비어 있어 정확한 모델 비교가 불가능하다.

### 345 — Generator / Old · 보류

![345 Generator PZ 왼쪽 MC 오른쪽](images/345_PZ_vs_MC.jpg)

PZ Old 발전기는 원형 황색 부품과 노출된 엔진을 금속 파이프 프레임이 감싼 구조다. 기존 Minecraft 렌더는 검정 통풍구가 있는 막힌 직육면체로 원형 엔진·파이프 프레임이 없다. 또한 JSON 렌더는 부분 증거여서 전체 모델도 미확인.

### 346 — Grand Piano / Black · 조건부

![346 Grand Piano PZ 왼쪽 MC 오른쪽](images/346_PZ_vs_MC.jpg)

PZ와 Decocraft 후보는 모두 검정 그랜드 피아노이고 건반·페달·다리가 확인돼 물체 종류는 잘 맞는다. 그러나 PZ는 닫힌 둥근 곡면 상판인 반면 후보는 뚜껑이 열려 내부 현과 악보대가 드러난다. 다리 수·몸통 비율·2×3 배치와 기능은 확인되지 않았다.

### 347 — HK533p / Imekagi · 보류

![347 HK533p PZ 왼쪽 MC 오른쪽](images/347_PZ_vs_MC.jpg)

PZ HK533p Imekagi는 높은 삼각대에 설치된 크림색/검정 카메라로 상부 뷰파인더와 렌즈/손잡이가 보인다. Minecraft 후보가 없어서 삼각대와 카메라 구조를 비교할 수 없다.

### 348 — Shelves / Hardwood Wall Corner · 보류

![348 Shelves PZ 왼쪽 MC 오른쪽](images/348_PZ_vs_MC.jpg)

PZ Hardwood Wall Corner는 벽 모서리에 걸린 두 개의 얇은 ㄱ자 선반 판이며 하부가 완전히 열려 있다. Minecraft Handcrafted acacia_shelf 렌더는 큰 육면체 상자에 두 개의 검은 전면 틈이 있는 구조로 ㄱ자 판, 벽 코너 결합, 개방성이 재현되지 않는다.

### 349 — Sign / Laundromat · 보류

![349 Sign PZ 왼쪽 MC 오른쪽](images/349_PZ_vs_MC.jpg)

PZ는 가로로 네 타일 이어지는 세탁소 간판이다. 기존 후보는 세로형 파란 버스정류장 표지판으로 문구, 방향, 길이, 설치 방식이 전혀 다르며 기존 렌더도 LEGACY_3D_APPROXIMATION 등급이다.

### 350 — Bed / Crafted · 보류

![350 Bed PZ 왼쪽 MC 오른쪽](images/350_PZ_vs_MC.jpg)

PZ Crafted Bed는 낮은 단층 침대 1개로 갈색 목재 프레임과 흰 매트리스가 보인다. Minecraft 후보는 밝은 목재 사다리·난간이 있는 2층 침대여서 층수, 높이, 프레임 색상, 1×2 구조가 다르다.

</details>

<details>
<summary><strong>351–357 (7종, 조건부 0 / 보류 7)</strong></summary>

[이 묶음만 보기](batches/BATCH_351_357.md)

### 351 — Chair / Dentist Patient · 보류

![351 Chair PZ 왼쪽 MC 오른쪽](images/351_PZ_vs_MC.jpg)

PZ는 1×2 진료용 리클라이닝 체어와 발받침·금속 프레임이 일체화되어 있다. 기존 MC pfm:arm_chair_leather의 Blockbench 결과는 회색 평판처럼 보이는 부분 JSON 렌더라 팔걸이·발받침·기울기·1×2 형상을 검증할 수 없다. 용도도 일반 가죽 안락의자여서 승인 불가.

### 352 — Counter / Crafter Corner · 보류

![352 Counter PZ 왼쪽 MC 오른쪽](images/352_PZ_vs_MC.jpg)

PZ는 거친 갈색 목재 판재로 만든 L자 수제 코너이고, MC는 검정 본체와 은회색 가로띠가 두드러지는 식당 카운터다. 코너 실루엣만 비슷하며 색상·재질·판재 방향이 다르다.

### 353 — Counter / Oak Corner Bar · 보류

![353 Counter PZ 왼쪽 MC 오른쪽](images/353_PZ_vs_MC.jpg)

PZ는 밝은 오크 상판과 진한 목재 세로 패널을 조합한 코너 바인데 MC는 검정 상판과 회색 수평 줄무늬가 있는 식당 카운터다. 상판 색·세로 나뭇결·L자 길이와 방향이 불일치한다.

### 354 — Counter / Pizzawhirled Corner · 보류

![354 Counter PZ 왼쪽 MC 오른쪽](images/354_PZ_vs_MC.jpg)

PZ는 붉은 상판과 빨강·흰색 체크 타일 벽면이 특징인데 MC는 검정 본체와 회색 가로 띠다. 색상·체커보드 패턴·매장 정체성이 모두 다르다.

### 355 — Counter / Seahorse Coffee Corner · 보류

![355 Counter PZ 왼쪽 MC 오른쪽](images/355_PZ_vs_MC.jpg)

PZ는 밝은 황토색 상판과 어두운 갈색의 무늬 없는 목재 몸체로 구성되지만 MC는 검정 상판과 은회색 가로 줄무늬다. 상판 색상·하부 재질·띠 유무가 다르다.

### 356 — Counter / Spiffos Corner · 보류

![356 Counter PZ 왼쪽 MC 오른쪽](images/356_PZ_vs_MC.jpg)

PZ는 주황 상판·갈색 몸체·초록색 장식 띠가 핵심인데 MC는 검정 상판과 은회색 줄무늬다. 주황/초록 배색과 전면 패널 구조가 모두 불일치한다.

### 357 — Table / Quality · 보류

![357 Table PZ 왼쪽 MC 오른쪽](images/357_PZ_vs_MC.jpg)

PZ는 짙은 갈색 원목 상판과 네 개의 굵은 다리가 있는 소형 목재 테이블이다. MC acacia_glass_table의 비교 이미지는 밝은 주황색 평판만 보이는 불완전한 부분 JSON 렌더이며 유리/다리 구조가 확인되지 않는다. 재질·색상·형상이 일치하지 않는다.

</details>

